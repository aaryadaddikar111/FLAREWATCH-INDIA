# FlareWatch India — Final 2D NOAA-connected prototype

## Pages
- `index.html` — launcher; redirects to Live Space Weather. There is no Overview page.
- `live-space-weather.html` — current NOAA SWPC conditions.
- `routes.html` — aviation route analysis with 2D Leaflet map.
- `drone-zones.html` — drone mission analysis with 2D Leaflet map.
- `storm-simulator.html` — historical May 2024 storm route-change demonstration only.
- `alerts.html` — NOAA SWPC alerts.

## NOAA inputs
The browser fetches NOAA SWPC public feeds for:
- Planetary Kp index
- Kp forecast
- GOES X-ray flux / flare information
- GOES integral proton flux for the radiation indicator
- Real-time solar-wind speed/density
- Solar-wind magnetic field / Bz GSM
- NOAA alerts

The prototype refreshes live space weather every 60 seconds on the Live and Aviation pages.

## Route behaviour
- LOW / MODERATE: no automatic reroute.
- HIGH: reroute when the alternate corridor lowers the modeled route score.
- SEVERE: a visible avoidance corridor is generated so the map changes and distance/duration/fuel trade-offs become visible.
- Blue = original route.
- Green dashed = suggested route.

The suggested route is a transparent demonstrator corridor, not a certified airway, ATC route, fuel plan, radiation dose calculation, or flight-safety decision.

## Radiation
Radiation is not inferred directly from Kp. The model uses the NOAA GOES proton-flux feed when available and combines it with route latitude and altitude for a prototype aviation exposure indicator. NOAA's S-scale is used as context for the proton-flux status.

## Fallback
If the browser cannot reach NOAA, the site clearly labels the data as `DEMO FALLBACK · NOAA UNAVAILABLE` rather than silently presenting demo values as live data.

## Run
Open the `flarewatch-india` folder in VS Code and run `index.html` with Live Server. Do not use `file:///...`.
