export const DEMO={
 low:{kpIndex:2.3,xrayFlux:'B7.1',solarFlare:'None detected',solarWindSpeed:410,solarWindDensity:5.8,bzGsm:-1,btGsm:5,geomagneticStatus:'Quiet',solarRadiation:'Normal',timestamp:new Date().toISOString(),dataStatus:'DEMO',dataSource:'FlareWatch simulation'},
 elevated:{kpIndex:4.7,xrayFlux:'C3.2',solarFlare:'C-class',solarWindSpeed:520,solarWindDensity:8.2,bzGsm:-4,btGsm:8,geomagneticStatus:'Unsettled',solarRadiation:'Normal',timestamp:new Date().toISOString(),dataStatus:'DEMO',dataSource:'FlareWatch simulation'},
 high:{kpIndex:6.2,xrayFlux:'M2.1',solarFlare:'M2.1',solarWindSpeed:650,solarWindDensity:11.4,bzGsm:-7,btGsm:14,geomagneticStatus:'G2 Moderate',solarRadiation:'Elevated',timestamp:new Date().toISOString(),dataStatus:'DEMO',dataSource:'FlareWatch simulation'},
 storm:{kpIndex:9,xrayFlux:'X5.8',solarFlare:'X5.8',solarWindSpeed:null,solarWindDensity:null,bzGsm:-20,btGsm:30,geomagneticStatus:'G5 Extreme',solarRadiation:'Elevated',timestamp:'2024-05-11T00:00:00Z',dataStatus:'HISTORICAL SIMULATION',dataSource:'NOAA historical May 2024 scenario'}
};
