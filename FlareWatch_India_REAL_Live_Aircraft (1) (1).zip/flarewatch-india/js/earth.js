import {fetchSpaceWeather, normalizeDemo} from './api.js';
import {DEMO} from '../data/demoData.js';
import {searchAirports, findAirport, greatCircle, haversine} from './routeEngine.js';

const $=s=>document.querySelector(s);
let wx=null, globe=null, route=null, source=null, destination=null, geojson=null;
let autoRotate=true, labelsVisible=true, atmosphereVisible=true, activityVisible=true;

const MAJOR_LABELS=[
  ['EUROPE',50,15,1.15,'#a9b2bd'],['AFRICA',5,20,1.1,'#a9b2bd'],['ASIA',40,85,1.05,'#a9b2bd'],
  ['NORTH ATLANTIC OCEAN',29,-38,0.78,'#6fa9c8'],['SOUTH ATLANTIC OCEAN',-29,-17,0.72,'#6fa9c8'],
  ['North America',45,-102,0.45,'#aab4bd'],['South America',-15,-58,0.45,'#aab4bd'],
  ['Greenland',72,-42,0.38,'#eef5fb'],['Canada',57,-106,0.36,'#eef5fb'],['United States',38,-97,0.36,'#eef5fb'],
  ['Brazil',-10,-52,0.36,'#eef5fb'],['Morocco',31,-7,0.34,'#eef5fb'],['Algeria',28,2,0.34,'#eef5fb'],
  ['Nigeria',9,8,0.34,'#eef5fb'],['Egypt',27,30,0.34,'#eef5fb'],['France',46,2,0.34,'#eef5fb'],
  ['Spain',40,-4,0.34,'#eef5fb'],['Italy',42,12,0.34,'#eef5fb'],['United Kingdom',54,-3,0.34,'#eef5fb'],
  ['Norway',62,9,0.34,'#eef5fb'],['Germany',51,10,0.34,'#eef5fb'],['Greece',39,22,0.34,'#eef5fb'],
  ['Russia',57,80,0.34,'#eef5fb'],['Kazakhstan',48,68,0.32,'#eef5fb'],['India',22,79,0.34,'#eef5fb'],
  ['Pakistan',30,69,0.32,'#eef5fb'],['Saudi Arabia',24,45,0.32,'#eef5fb'],['South Africa',-30,24,0.32,'#eef5fb']
];

function status(){
  const live=wx?.dataStatus && wx.dataStatus!=='DEMO' && wx.dataStatus!=='SIMULATION';
  $('#earthStatus').innerHTML=`<span class="dot ${live?'live':'error'}"></span>${wx?.dataStatus||'CONNECTING'}`;
  $('#earthMode').textContent=wx?.dataStatus||'CONNECTING';
  const kp=Number(wx?.kpIndex)||0;
  $('#earthKp').textContent=Number.isFinite(wx?.kpIndex)?wx.kpIndex.toFixed(1):'—';
  $('#earthXray').textContent=wx?.xrayFlux||'—';
  $('#earthFlare').textContent=wx?.solarFlare||'—';
  $('#earthGeo').textContent=wx?.geomagneticStatus||'—';
  $('#earthWind').textContent=Number.isFinite(wx?.solarWindSpeed)?Math.round(wx.solarWindSpeed)+' km/s':'—';
  $('#earthUpdated').textContent=wx?.timestamp?new Date(wx.timestamp).toLocaleString():'—';
  const storm=kp>=7||String(wx?.solarFlare||'').startsWith('M')||String(wx?.solarFlare||'').startsWith('X');
  $('#earthStorm').textContent=storm?'STORM CONDITIONS':kp>=4?'ELEVATED ACTIVITY':'NORMAL';
  $('#earthStorm').className=`pill ${storm?'storm-pill':kp>=4?'warn-pill':'muted-pill'}`;
  $('#activityText').textContent=storm?'Simulated/severe activity is emphasized with luminous polar particles and a stronger atmospheric glow.':'The globe uses subtle luminous activity markers to represent modeled geomagnetic activity.';
  if(globe) updateActivity();
}

function setupAirportBox(inputId,menuId){
  const input=$(inputId), menu=$(menuId);
  const render=()=>{
    const items=searchAirports(input.value);
    menu.innerHTML=items.map(a=>`<button type="button" data-iata="${a.iata}"><b>${a.iata}</b> · ${a.city}<small>${a.name}</small></button>`).join('');
    menu.classList.toggle('show',items.length>0);
  };
  input.addEventListener('input',render); input.addEventListener('focus',render);
  input.addEventListener('blur',()=>setTimeout(()=>menu.classList.remove('show'),150));
  menu.addEventListener('mousedown',e=>{
    const b=e.target.closest('button'); if(!b)return;
    const a=findAirport(b.dataset.iata); input.value=`${a.city} (${a.iata})`; input.dataset.iata=a.iata; menu.classList.remove('show');
  });
}

function centroid(feature){
  const g=feature.geometry; const pts=[];
  const collect=x=>{if(Array.isArray(x)&&typeof x[0]==='number')pts.push(x);else if(Array.isArray(x))x.forEach(collect)};
  collect(g.coordinates);
  if(!pts.length)return null;
  let lon=0,lat=0; pts.forEach(p=>{lon+=p[0];lat+=p[1]});
  return {lat:lat/pts.length,lon:lon/pts.length};
}

function buildLabels(){
  const countryLabels=(geojson?.features||[]).map(f=>{
    const c=centroid(f); const name=f.properties?.name||f.properties?.NAME||f.properties?.ADMIN;
    if(!c||!name)return null;
    const allow=/Canada|Greenland|United States|Brazil|Mexico|Morocco|Algeria|Nigeria|Egypt|France|Spain|Italy|United Kingdom|Norway|Germany|Greece|Russia|Kazakhstan|India|Pakistan|Saudi|South Africa|Australia|Japan|China|Iceland|Portugal|Turkey|Ukraine|Sweden|Finland|Poland|Cuba|Colombia|Argentina|Chile|Peru/.test(name);
    return allow?{lat:c.lat,lng:c.lon,text:name,size:0.34,color:'#f3f5f6'}:null;
  }).filter(Boolean);
  const majors=MAJOR_LABELS.map(([text,lat,lng,size,color])=>({lat,lng,text,size,color,major:true}));
  return [...countryLabels,...majors];
}

function createGlobe(){
  globe=Globe()(document.getElementById('globeViz'))
    .backgroundColor('rgba(0,0,0,0)')
    .showAtmosphere(atmosphereVisible)
    .atmosphereColor('#bfe9ff')
    .atmosphereAltitude(0.17)
    .globeMaterial(new THREE.MeshPhongMaterial({color:'#67c7ed',emissive:'#062538',emissiveIntensity:0.22,shininess:18}))
    .polygonsData(geojson?.features||[])
    .polygonAltitude(0.012)
    .polygonCapColor(()=> 'rgba(186,231,166,0.88)')
    .polygonSideColor(()=> 'rgba(90,150,105,0.28)')
    .polygonStrokeColor(()=> 'rgba(205,236,205,0.62)')
    .polygonLabel(d=>`<div style="padding:4px 7px;border-radius:6px;background:rgba(3,9,14,.88);border:1px solid rgba(255,255,255,.16);color:#fff;font-size:11px">${d.properties?.name||d.properties?.NAME||d.properties?.ADMIN||''}</div>`)
    .labelsData(buildLabels())
    .labelLat(d=>d.lat).labelLng(d=>d.lng).labelText(d=>d.text).labelSize(d=>d.size)
    .labelColor(d=>d.color).labelDotRadius(d=>d.major?0:0.16).labelResolution(2)
    .arcsData([]).arcColor(()=>['#ffb400','#8cff39']).arcAltitude(0.22).arcStroke(0.75).arcDashLength(0.45).arcDashGap(1.5).arcDashAnimateTime(1700)
    .pointsData([]).pointLat(d=>d.lat).pointLng(d=>d.lng).pointColor(d=>d.color).pointRadius(d=>d.radius).pointAltitude(0.03).pointResolution(12)
    .ringsData([]).ringLat(d=>d.lat).ringLng(d=>d.lng).ringColor(d=>d.color).ringMaxRadius(d=>d.maxRadius).ringPropagationSpeed(1.2).ringRepeatPeriod(1200);

  globe.controls().autoRotate=true; globe.controls().autoRotateSpeed=0.18; globe.controls().enableDamping=true; globe.controls().dampingFactor=0.08; globe.controls().minDistance=120; globe.controls().maxDistance=520;
  globe.pointOfView({lat:28,lng:5,altitude:2.05},900);
  resizeGlobe();
}

function updateActivity(){
  if(!globe)return;
  const kp=Number(wx?.kpIndex)||0;
  const polarStrength=Math.max(0.12,Math.min(1,(kp+1)/9));
  const activity=[];
  for(let i=0;i<18;i++){
    const lng=-180+i*20;
    activity.push({lat:68+Math.sin(i*1.7)*4,lng,color:kp>=7?'#ff6a4d':kp>=4?'#ffd166':'#74cfff',maxRadius:kp>=7?2.6:1.6,radius:kp>=7?0.22:0.14});
  }
  if(kp>=5) for(let i=0;i<12;i++) activity.push({lat:-68+Math.cos(i*1.4)*3,lng:-180+i*30,color:'#74cfff',maxRadius:1.4,radius:.12});
  globe.ringsData(activityVisible?activity:[]).pointColor(d=>d.color).ringColor(d=>d.color).ringMaxRadius(d=>d.maxRadius);
  globe.showAtmosphere(atmosphereVisible); globe.atmosphereAltitude(atmosphereVisible?(kp>=7?0.22:0.17):0);
}

function showRoute(a,b){
  source=a; destination=b;
  const points=greatCircle(a,b,70);
  globe.arcsData([{startLat:a.lat,startLng:a.lon,endLat:b.lat,endLng:b.lon,label:`${a.iata} → ${b.iata}`}]);
  globe.pointsData([{lat:a.lat,lng:a.lon,color:'#62ff7e',radius:.42,label:`${a.city} (${a.iata}) · SOURCE`},{lat:b.lat,lng:b.lon,color:'#63b3ff',radius:.42,label:`${b.city} (${b.iata}) · DESTINATION`}]);
  globe.ringsData([{lat:a.lat,lng:a.lon,color:'#62ff7e',maxRadius:.8},{lat:b.lat,lng:b.lon,color:'#63b3ff',maxRadius:.8}]);
  const mid=points[Math.floor(points.length/2)];
  globe.pointOfView({lat:mid.lat,lng:mid.lon,altitude:1.95},1200);
  const distance=haversine(a,b);
  $('#earthRouteInfo').style.display='block';
  $('#earthRouteInfo').innerHTML=`<b>${a.iata} → ${b.iata}</b><span>${a.city} to ${b.city}</span><strong>${Math.round(distance).toLocaleString()} km</strong><small>Animated great-circle route</small>`;
}

function clearRoute(){source=destination=null; globe.arcsData([]); globe.pointsData([]); globe.ringsData(activityVisible?[]:[]); updateActivity(); $('#earthRouteInfo').style.display='none'; globe.pointOfView({lat:28,lng:5,altitude:2.05},1000);}

async function loadWeather(mode='live'){
  try{wx=await fetchSpaceWeather(); if(mode==='simulation')return;}catch{wx=normalizeDemo(DEMO.elevated)}
  status();
}

function resizeGlobe(){
  const el=$('#globeViz'); if(globe&&el) globe.width(el.clientWidth).height(el.clientHeight);
}

async function init(){
  setupAirportBox('#earthSource','#earthSourceMenu'); setupAirportBox('#earthDestination','#earthDestinationMenu');
  try{
    const res=await fetch('https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson',{cache:'force-cache'});
    if(!res.ok)throw new Error('World GeoJSON unavailable'); geojson=await res.json();
  }catch(e){geojson={features:[]}; console.warn('Country boundaries could not be loaded.',e)}
  createGlobe();
  try{wx=await fetchSpaceWeather()}catch{wx=normalizeDemo(DEMO.elevated)} status();

  $('#earthRouteForm').addEventListener('submit',e=>{e.preventDefault();const a=findAirport($('#earthSource').dataset.iata||$('#earthSource').value);const b=findAirport($('#earthDestination').dataset.iata||$('#earthDestination').value);if(!a||!b){alert('Select valid airports from the suggestions.');return}showRoute(a,b)});
  $('#earthClearRoute').addEventListener('click',clearRoute);
  $('#earthSimulate').addEventListener('click',()=>{wx=normalizeDemo(DEMO.storm);wx.dataStatus='SIMULATION';status();$('#earthSimulationNotice').style.display='block'});
  $('#earthReset').addEventListener('click',async()=>{ $('#earthSimulationNotice').style.display='none'; await loadWeather(); });
  $('#earthRefresh').addEventListener('click',async()=>{await loadWeather()});
  $('#toggleLabels').addEventListener('change',e=>{labelsVisible=e.target.checked;globe.labelsData(labelsVisible?buildLabels():[])});
  $('#toggleAtmosphere').addEventListener('change',e=>{atmosphereVisible=e.target.checked;globe.showAtmosphere(atmosphereVisible);updateActivity()});
  $('#toggleActivity').addEventListener('change',e=>{activityVisible=e.target.checked;updateActivity()});
  $('#toggleAutoRotate').addEventListener('change',e=>{autoRotate=e.target.checked;globe.controls().autoRotate=autoRotate});
  window.addEventListener('resize',resizeGlobe);
}
init();
