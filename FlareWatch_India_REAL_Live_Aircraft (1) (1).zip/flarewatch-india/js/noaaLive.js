// NOAA SWPC live-data service used by the Live Space Weather dashboard.
// No demo values are used here. If a feed is unavailable, the caller receives
// a clear unavailable state instead of silently substituting simulated data.

const BASE = 'https://services.swpc.noaa.gov';

export const NOAA_LIVE_ENDPOINTS = Object.freeze({
  kp: `${BASE}/json/planetary_k_index_1m.json`,
  xray: `${BASE}/json/goes/primary/xrays-1-day.json`,
  wind: `${BASE}/json/rtsw/rtsw_wind_1m.json`,
  windMag: `${BASE}/products/summary/solar-wind-mag-field.json`,
  windSpeed: `${BASE}/products/summary/solar-wind-speed.json`,
  proton: `${BASE}/json/goes/primary/integral-protons-1-day.json`,
  alerts: `${BASE}/products/alerts.json`,
  kpTrend: `${BASE}/products/noaa-planetary-k-index.json`,
  kpForecast: `${BASE}/products/noaa-planetary-k-index-forecast.json`
});

const FETCH_TIMEOUT_MS = 15000;

async function getJSON(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      cache: 'no-store',
      signal: controller.signal,
      headers: { Accept: 'application/json' }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

function rowsToObjects(payload) {
  if (!Array.isArray(payload) || payload.length === 0) return [];
  if (Array.isArray(payload[0])) {
    const headers = payload[0];
    return payload.slice(1).map(row => Object.fromEntries(
      headers.map((key, index) => [key, row[index]])
    ));
  }
  return payload;
}

function timeValue(row) {
  const value = row?.time_tag ?? row?.timeTag ?? row?.timestamp ?? row?.time ?? row?.issue_datetime;
  const ms = value ? Date.parse(value) : NaN;
  return Number.isFinite(ms) ? ms : -Infinity;
}

function latestValid(rows, predicate = () => true) {
  let best = null;
  let bestTime = -Infinity;
  for (const row of rows) {
    if (!predicate(row)) continue;
    const t = timeValue(row);
    if (t >= bestTime) {
      best = row;
      bestTime = t;
    }
  }
  return best;
}

function firstFinite(row, keys) {
  for (const key of keys) {
    const value = Number(row?.[key]);
    if (Number.isFinite(value)) return value;
  }
  return null;
}

function numericField(row, keys) {
  return firstFinite(row, keys);
}

function getKp(rows) {
  const row = latestValid(rows, r => Number.isFinite(firstFinite(r, ['Kp', 'kp', 'kp_index', 'estimated_kp'])));
  return row ? firstFinite(row, ['Kp', 'kp', 'kp_index', 'estimated_kp']) : null;
}

function getKpHistory(rows) {
  return rows
    .map(row => ({
      kp: firstFinite(row, ['Kp', 'kp', 'kp_index', 'estimated_kp']),
      time: row?.time_tag ?? row?.timeTag ?? row?.timestamp
    }))
    .filter(row => Number.isFinite(row.kp) && row.time)
    .sort((a, b) => Date.parse(a.time) - Date.parse(b.time))
    .slice(-12);
}

function isXrayBand(row) {
  const wavelength = String(
    row?.energy ?? row?.energy_band ?? row?.channel ?? row?.wavelength ?? ''
  ).toLowerCase();
  // NOAA GOES X-ray product normally labels this as "0.1-0.8nm".
  return wavelength.includes('0.1') && wavelength.includes('0.8');
}

function getLatestXray(rows) {
  const candidates = rows.filter(isXrayBand);
  const usable = candidates.length ? candidates : rows;
  const row = latestValid(usable, r => Number.isFinite(firstFinite(r, ['flux', 'observed_flux', 'xray_flux'])));
  if (!row) return null;
  return {
    flux: firstFinite(row, ['flux', 'observed_flux', 'xray_flux']),
    time: row?.time_tag ?? row?.timeTag ?? row?.timestamp,
    satellite: row?.satellite ?? null
  };
}

function xrayClass(flux) {
  if (!Number.isFinite(flux) || flux <= 0) return 'Data temporarily unavailable';
  const thresholds = [
    ['X', 1e-4],
    ['M', 1e-5],
    ['C', 1e-6],
    ['B', 1e-7],
    ['A', 1e-8]
  ];
  for (const [letter, threshold] of thresholds) {
    if (flux >= threshold) return `${letter}${(flux / threshold).toFixed(1)}`;
  }
  return `A${(flux / 1e-8).toFixed(1)}`;
}

function geomagneticCondition(kp) {
  if (!Number.isFinite(kp)) return 'Data temporarily unavailable';
  if (kp >= 9) return 'G5 Extreme';
  if (kp >= 8) return 'G4 Severe';
  if (kp >= 7) return 'G3 Strong';
  if (kp >= 6) return 'G2 Moderate';
  if (kp >= 5) return 'G1 Minor';
  if (kp >= 4) return 'Unsettled';
  return 'Quiet';
}

function radioBlackout(flux) {
  if (!Number.isFinite(flux)) return 'Data temporarily unavailable';
  if (flux >= 2e-3) return 'R5 Extreme';
  if (flux >= 1e-3) return 'R4 Severe';
  if (flux >= 1e-4) return 'R3 Strong';
  if (flux >= 5e-5) return 'R2 Moderate';
  if (flux >= 1e-5) return 'R1 Minor';
  return 'R0 No Impact';
}

function protonFlux(rows) {
  const normalized = rows.map(row => {
    const energy = String(row?.energy ?? row?.energy_channel ?? row?.channel ?? '').toLowerCase();
    return { row, energy };
  });

  const preferred = normalized.filter(({ energy }) =>
    energy.includes('>10') || energy.includes('10 mev') || energy.includes('p10')
  );
  const pool = preferred.length ? preferred : normalized;
  const row = latestValid(pool.map(x => x.row), r => Number.isFinite(firstFinite(r, ['flux', 'integral_flux', 'p10_flux', 'flux_pfu'])));
  return row ? {
    flux: firstFinite(row, ['flux', 'integral_flux', 'p10_flux', 'flux_pfu']),
    time: row?.time_tag ?? row?.timeTag ?? row?.timestamp,
    energy: row?.energy ?? row?.energy_channel ?? row?.channel ?? null
  } : null;
}

function radiationScale(pfu) {
  if (!Number.isFinite(pfu)) return 'Data temporarily unavailable';
  if (pfu >= 100000) return 'S5 Extreme';
  if (pfu >= 10000) return 'S4 Severe';
  if (pfu >= 1000) return 'S3 Strong';
  if (pfu >= 100) return 'S2 Moderate';
  if (pfu >= 10) return 'S1 Minor';
  return 'Below S1';
}

function getWind(rows) {
  const row = latestValid(rows, r => Number.isFinite(firstFinite(r, ['proton_speed', 'speed', 'bulk_speed'])));
  return row ? {
    speed: firstFinite(row, ['proton_speed', 'speed', 'bulk_speed']),
    density: firstFinite(row, ['proton_density', 'density']),
    time: row?.time_tag ?? row?.timeTag ?? row?.timestamp
  } : null;
}

function getMag(rows) {
  const row = latestValid(rows, r =>
    Number.isFinite(firstFinite(r, ['bt', 'total_field', 'bt_gsm'])) ||
    Number.isFinite(firstFinite(r, ['bz_gsm', 'bz']))
  );
  return row ? {
    bt: firstFinite(row, ['bt', 'total_field', 'bt_gsm']),
    bz: firstFinite(row, ['bz_gsm', 'bz']),
    time: row?.time_tag ?? row?.timeTag ?? row?.timestamp
  } : null;
}

function summaryNumber(payload, keys) {
  const rows = rowsToObjects(payload);
  const row = latestValid(rows, r => Number.isFinite(firstFinite(r, keys)));
  return row ? { value: firstFinite(row, keys), time: row?.time_tag ?? row?.timeTag ?? row?.timestamp } : null;
}

export function normalizeNoaaLive(raw) {
  const kpRows = rowsToObjects(raw.kp);
  const xrayRows = rowsToObjects(raw.xray);
  const windRows = rowsToObjects(raw.wind);
  const magRows = rowsToObjects(raw.windMag);
  const protonRows = rowsToObjects(raw.proton);

  const kp = getKp(kpRows);
  const xray = getLatestXray(xrayRows);
  const wind = getWind(windRows);
  const windSummary = summaryNumber(raw.windSpeed, ['proton_speed', 'speed', 'bulk_speed']);
  const mag = getMag(magRows);
  const proton = protonFlux(protonRows);

  const timestamps = [kpRows, xrayRows, windRows, magRows, protonRows]
    .flat()
    .map(timeValue)
    .filter(Number.isFinite);
  const latestObservationMs = timestamps.length ? Math.max(...timestamps) : NaN;

  const missing = [];
  if (!Number.isFinite(kp)) missing.push('Kp');
  if (!xray) missing.push('X-ray');
  if (!wind && !windSummary) missing.push('solar wind');
  if (!mag) missing.push('magnetic field');
  if (!proton) missing.push('proton flux');

  if (missing.length === 5) {
    throw new Error(`NOAA live observations unavailable: ${missing.join(', ')}`);
  }

  const speed = wind?.speed ?? windSummary?.value ?? null;
  const density = wind?.density ?? null;
  const flare = xray ? xrayClass(xray.flux) : 'Data temporarily unavailable';

  return {
    kpIndex: kp,
    xrayFlux: xray ? xrayClass(xray.flux) : 'Data temporarily unavailable',
    xrayWatts: xray?.flux ?? null,
    solarFlare: flare,
    solarWindSpeed: speed,
    solarWindDensity: density,
    btGsm: mag?.bt ?? null,
    bzGsm: mag?.bz ?? null,
    protonFlux: proton?.flux ?? null,
    protonEnergy: proton?.energy ?? null,
    solarRadiation: radiationScale(proton?.flux),
    geomagneticStatus: geomagneticCondition(kp),
    radioBlackout: radioBlackout(xray?.flux),
    timestamp: Number.isFinite(latestObservationMs) ? new Date(latestObservationMs).toISOString() : null,
    lastUpdated: new Date().toISOString(),
    dataStatus: 'NOAA LIVE',
    dataSource: 'NOAA SWPC',
    feedErrors: raw.errors ?? [],
    missing,
    history: getKpHistory(kpRows)
  };
}

export async function fetchNoaaLive() {
  const names = ['kp', 'xray', 'wind', 'windMag', 'windSpeed', 'proton'];
  const settled = await Promise.allSettled(names.map(name => getJSON(NOAA_LIVE_ENDPOINTS[name])));
  const raw = {};
  const errors = [];

  names.forEach((name, index) => {
    const result = settled[index];
    if (result.status === 'fulfilled') raw[name] = result.value;
    else {
      raw[name] = null;
      errors.push(name);
    }
  });
  raw.errors = errors;

  const normalized = normalizeNoaaLive(raw);
  normalized.alerts = await fetchNoaaAlerts().catch(() => []);
  return normalized;
}

export async function fetchNoaaAlerts() {
  const payload = await getJSON(NOAA_LIVE_ENDPOINTS.alerts);
  return Array.isArray(payload) ? payload : [];
}

export async function fetchNoaaKpTrend() {
  const payload = await getJSON(NOAA_LIVE_ENDPOINTS.kpTrend);
  const rows = rowsToObjects(payload);
  return rows
    .map(row => ({
      kp: firstFinite(row, ['Kp', 'kp', 'kp_index', 'estimated_kp']),
      time: row?.time_tag ?? row?.timeTag ?? row?.timestamp
    }))
    .filter(row => Number.isFinite(row.kp) && row.time)
    .sort((a, b) => Date.parse(a.time) - Date.parse(b.time))
    .slice(-12);
}


export async function fetchNoaaKpForecast() {
  const payload = await getJSON(NOAA_LIVE_ENDPOINTS.kpForecast);
  const rows = rowsToObjects(payload);
  return rows
    .filter(row => String(row?.observed ?? '').toLowerCase() === 'predicted' || String(row?.observed ?? '').toLowerCase() === 'estimated')
    .map(row => ({
      kp: firstFinite(row, ['kp', 'Kp', 'estimated_kp']),
      time: row?.time_tag ?? row?.timeTag ?? row?.timestamp
    }))
    .filter(row => Number.isFinite(row.kp) && row.time)
    .slice(0, 8);
}
