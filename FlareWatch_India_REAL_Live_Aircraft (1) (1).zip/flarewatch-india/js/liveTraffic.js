// Real-time ADS-B aircraft positions from public community aggregators.
// Coverage is strongest where volunteer receivers are present; this is NOT
// certified ATC/radar data. The browser uses CORS-enabled public endpoints.

const PROVIDERS = [
  { name: 'adsb.lol', point: (lat, lon, r) => `https://api.adsb.lol/v2/point/${lat}/${lon}/${r}` },
  { name: 'airplanes.live', point: (lat, lon, r) => `https://api.airplanes.live/v2/point/${lat}/${lon}/${r}` },
  { name: 'adsb.fi', point: (lat, lon, r) => `https://opendata.adsb.fi/api/v2/point/${lat}/${lon}/${r}` },
  { name: 'adsb.one', point: (lat, lon, r) => `https://api.adsb.one/v2/point/${lat}/${lon}/${r}` }
];

export const INDIA_HUBS = [
  { name: 'Delhi', lat: 28.6139, lon: 77.2090 },
  { name: 'Mumbai', lat: 19.0760, lon: 72.8777 },
  { name: 'Bengaluru', lat: 12.9716, lon: 77.5946 },
  { name: 'Chennai', lat: 13.0827, lon: 80.2707 },
  { name: 'Kolkata', lat: 22.5726, lon: 88.3639 },
  { name: 'Hyderabad', lat: 17.3850, lon: 78.4867 }
];

const RADIUS_NM = 250;
const FETCH_TIMEOUT_MS = 12000;

function altToFt(v) {
  if (v === 'ground') return 0;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function rowToAircraft(ac, providerNow) {
  if (ac.lat == null || ac.lon == null) return null;
  const seen = Number(ac.seen);
  return {
    hex: ac.hex,
    callsign: (ac.flight || '').trim() || 'UNKNOWN',
    lat: Number(ac.lat),
    lon: Number(ac.lon),
    onGround: ac.alt_baro === 'ground',
    altitudeFt: altToFt(ac.alt_baro),
    speedKt: Number.isFinite(Number(ac.gs)) ? Number(ac.gs) : null,
    headingDeg: Number.isFinite(Number(ac.track)) ? Number(ac.track) : null,
    category: ac.category || '—',
    squawk: ac.squawk || '—',
    seenSeconds: Number.isFinite(seen) ? seen : null,
    providerTimestamp: Number.isFinite(Number(providerNow)) ? Number(providerNow) * 1000 : null
  };
}

async function getJSON(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const response = await fetch(url, { cache: 'no-store', signal: controller.signal, headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchLiveAircraft(hubs = INDIA_HUBS) {
  const errors = [];
  for (const provider of PROVIDERS) {
    const byHex = new Map();
    let successfulHubs = 0;
    let latestProviderNow = null;
    for (const hub of hubs) {
      try {
        const data = await getJSON(provider.point(hub.lat, hub.lon, RADIUS_NM));
        successfulHubs++;
        if (Number.isFinite(Number(data?.now))) latestProviderNow = Math.max(latestProviderNow || 0, Number(data.now));
        const list = Array.isArray(data?.ac) ? data.ac : [];
        list.map(a => rowToAircraft(a, data?.now)).filter(Boolean).forEach(a => byHex.set(a.hex, a));
      } catch (err) {
        errors.push(`${provider.name}/${hub.name}: ${err?.message || 'request failed'}`);
      }
    }
    if (successfulHubs > 0) {
      const aircraft = [...byHex.values()];
      return {
        timestamp: new Date(),
        providerTimestamp: latestProviderNow ? new Date(latestProviderNow * 1000) : null,
        source: provider.name,
        hubsSucceeded: successfulHubs,
        hubsTotal: hubs.length,
        aircraft,
        errors
      };
    }
  }
  throw new Error(errors.slice(-1)[0] || 'No live ADS-B provider responded');
}
