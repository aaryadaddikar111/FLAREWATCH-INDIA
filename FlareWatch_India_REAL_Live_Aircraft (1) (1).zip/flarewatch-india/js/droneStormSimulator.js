import {fetchSpaceWeather} from './api.js';
import {MapEngine} from './mapEngine.js';
import {scoreRoute, routeMetrics, spaceWeatherSeverity} from './operationalModel.js';

const $=s=>document.querySelector(s), n=s=>Number($(s).value)||0;
let map,wx=null;

const DEMO_STORMS={
  moderate:{kp:5,geomagneticStatus:'G1 Minor / elevated'},
  strong:{kp:7,geomagneticStatus:'G3 Strong'},
  extreme:{kp:9,geomagneticStatus:'G5 Extreme'}
};

function pathFromStart(){
  const lat=n('#startLat')||19.076, lon=n('#startLon')||72.877;
  const d=Math.max(.012, Math.min(.06, (n('#duration')||.5)*.035));
  return [
    {lat,lon},
    {lat:lat+d*.55,lon:lon+d*.80},
    {lat:lat+d*.95,lon:lon+d*.45},
    {lat:lat+d*.55,lon:lon-d*.35},
    {lat:lat-d*.10,lon:lon-d*.55}
  ];
}

function profile(){return{altitude:n('#altitude')||120,missionDuration:n('#duration')||.5,operatingRadius:5,gnssDependency:'High',backupNavigation:'INS',communicationSystem:'RF + LTE',missionCriticality:'Routine',droneType:'Multirotor',receiverType:'Single Frequency',augmentation:'None'};}

function stormWx(){
  const mode=$('#stormMode').value;
  if(mode==='live') return wx||{};
  const s=DEMO_STORMS[mode];
  return {...(wx||{}),kpIndex:s.kp,geomagneticStatus:s.geomagneticStatus};
}

function suggestedPath(original,weather){
  const severity=spaceWeatherSeverity(weather);
  // Always draw an alternate corridor in the simulator so the comparison is
  // visible even during quiet live conditions. The displacement scales with
  // the modeled storm severity; endpoints remain fixed.
  const shift=Math.max(.008,Math.min(.045,.008+severity/100*0.037));
  const sign=original[0].lat>=0?-1:1;
  return original.map((p,i)=>{
    if(i===0||i===original.length-1)return {...p};
    const t=i/(original.length-1),bend=Math.sin(Math.PI*t);
    return {lat:p.lat+sign*shift*bend,lon:p.lon+shift*.55*bend};
  });
}

// FIX: labels now match the real RISK_BANDS from operationalModel.js
// (LOW / MODERATE / HIGH / SEVERE). Previously every band displayed one
// notch below its true severity — a SEVERE exposure showed the word
// "High" — which understated risk to whoever was reading it. The colors
// were already correct; only the wording was wrong.
function riskClass(r){return r==='SEVERE'?'risk-high-text':r==='HIGH'?'risk-moderate-text':r==='MODERATE'?'risk-mild-text':'risk-low-text';}
function riskLabel(r){return r==='SEVERE'?'Severe':r==='HIGH'?'High':r==='MODERATE'?'Moderate':'Low';}
function riskLevelKey(r){return r==='SEVERE'?'severe':r==='HIGH'?'high':r==='MODERATE'?'moderate':'low';}
function levelLabel(k){return k==='severe'?'Severe':k==='high'?'High':k==='moderate'?'Moderate':'Low';}

function setMetricBox(id,levelKey){
  const el=$(id);
  if(!el)return;
  el.classList.remove('metricbox-low','metricbox-moderate','metricbox-high','metricbox-severe');
  el.classList.add('metricbox-'+levelKey);
}

// Animates a metric from its previous value to the new one instead of
// snapping instantly, so re-running the simulation feels alive.
function animateNumber(id,newVal,suffix){
  const el=$(id);
  if(!el)return;
  const prev=parseFloat(el.dataset.raw||'0')||0;
  const start=performance.now(), dur=550;
  function step(t){
    const p=Math.min(1,(t-start)/dur);
    const eased=1-Math.pow(1-p,3);
    const val=prev+(newVal-prev)*eased;
    el.textContent=`${val.toFixed(1)}${suffix||''}`;
    if(p<1)requestAnimationFrame(step); else el.dataset.raw=String(newVal);
  }
  requestAnimationFrame(step);
  el.classList.remove('pop-update');void el.offsetWidth;el.classList.add('pop-update');
}

// Drives the new colour-graded severity gauge + the screen-flash cue that
// fires when the modeled condition reaches SEVERE.
function updateSeverityGauge(weather){
  const severity=Math.max(0,Math.min(100,spaceWeatherSeverity(weather)));
  const key=severity>=75?'severe':severity>=50?'high':severity>=25?'moderate':'low';
  const marker=$('#severityMarker'), label=$('#severityLabel'), flash=$('#stormFlash');
  if(marker)marker.style.left=severity+'%';
  if(label){
    label.textContent=`${levelLabel(key)} · ${severity.toFixed(0)}/100`;
    label.classList.remove('lvl-low','lvl-moderate','lvl-high','lvl-severe');
    label.classList.add('lvl-'+key);
  }
  if(flash){
    flash.classList.remove('flash-active');
    if(key==='severe'){void flash.offsetWidth;flash.classList.add('flash-active');}
  }
  return {severity,key};
}

function render(){
  const original=pathFromStart(), weather=stormWx(), p=profile(), suggested=suggestedPath(original,weather);
  const a=scoreRoute(original,weather,p,'Drone'), b=scoreRoute(suggested,weather,p,'Drone');
  map.clear();
  map.addMarker(original[0],'Drone start','#58c77a',`<b>${$('#droneId').value||'FW-DRONE-01'}</b><br>Start / planned mission`);
  map.addMarker(original[original.length-1],'Mission end','#63b3ff','<b>Mission endpoint</b>');
  map.plotRoute(original,'#3f9fff','original',6);
  map.plotRoute(suggested,'#ffb400','suggested',6,'12 8');
  map.fit([original,suggested]);

  $('#mapTitle').textContent=`${$('#droneId').value||'FW-DRONE-01'} · actual path vs storm reroute`;
  const live=$('#stormMode').value==='live';
  $('#stormNotice').innerHTML=`<b>STORM REROUTE SIMULATION</b><br>${live?'Using live NOAA conditions.':'Using selected demo storm intensity.'}<br><span class="muted">Blue solid = actual/planned path · Orange dashed = suggested reroute · Kp ${Number(weather.kpIndex||0).toFixed(1)}</span>`;
  $('#stormNotice').classList.add('show');

  $('#kpValue').textContent=Number.isFinite(Number(weather.kpIndex))?Number(weather.kpIndex).toFixed(1):'—';
  $('#geoValue').textContent=weather.geomagneticStatus||'NOAA data unavailable';
  $('#originalRisk').textContent=riskLabel(a.risk);$('#originalRisk').className=riskClass(a.risk);
  $('#suggestedRisk').textContent=riskLabel(b.risk);$('#suggestedRisk').className=riskClass(b.risk);
  animateNumber('#originalScore',a.score,' / 100');
  animateNumber('#suggestedScore',b.score,' / 100');
  const change=a.score?((a.score-b.score)/a.score*100):0;
  $('#riskChange').textContent=`${change>=0?'-':'+'}${Math.abs(change).toFixed(1)}%`;

  setMetricBox('#originalMetric',riskLevelKey(a.risk));
  setMetricBox('#suggestedMetric',riskLevelKey(b.risk));
  setMetricBox('#changeMetric',change>=0?'low':'moderate');
  const gauge=updateSeverityGauge(weather);
  setMetricBox('#kpMetric',gauge.key);

  // Keep a tiny live telemetry marker at the starting point to connect the
  // simulator visually with the Drone mission page.
  if(window.__stormDroneMarker) window.__stormDroneMarker.remove();
  window.__stormDroneMarker=L.marker([original[0].lat,original[0].lon],{icon:L.divIcon({className:'fw-drone-icon',html:'<div class="drone-craft"><span class="drone-wing"></span><span class="drone-body">🛸</span></div>',iconSize:[38,38],iconAnchor:[19,19]})}).addTo(map.map);
  window.__stormDroneMarker.bindPopup(`<b>${$('#droneId').value||'FW-DRONE-01'}</b><br>DEMO TELEMETRY<br>Altitude: ${p.altitude} m`);
}

(async()=>{
  map=new MapEngine('stormMap',{center:[19,73],zoom:11}); await map.init();
  try{wx=await fetchSpaceWeather();$('#status').innerHTML='<span class="dot live"></span>NOAA LIVE';$('#mode').textContent='NOAA LIVE';}
  catch{wx={kpIndex:null,geomagneticStatus:'NOAA unavailable'};$('#status').innerHTML='<span class="dot error"></span>NOAA UNAVAILABLE';$('#mode').textContent='NOAA UNAVAILABLE';}
  $('#stormForm').addEventListener('submit',e=>{e.preventDefault();render();});
  $('#resetStorm').addEventListener('click',()=>{map.clear();$('#stormNotice').classList.remove('show');$('#mapTitle').textContent='Actual path vs suggested storm reroute';});
  // Instant preview: switching the demo storm dropdown re-renders right away
  // instead of waiting for a form submit, so the colour changes feel responsive.
  $('#stormMode').addEventListener('change',()=>{if($('#stormMode').value!=='live')render();});
  render();
  setInterval(async()=>{if($('#stormMode').value!=='live')return;try{wx=await fetchSpaceWeather();$('#mode').textContent='NOAA LIVE';render();}catch{}},60000);
})();
