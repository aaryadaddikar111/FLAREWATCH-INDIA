import {MapEngine} from './mapEngine.js';
import {searchAirports, findAirport, greatCircle} from './routeEngine.js';

const $ = s => document.querySelector(s);
let map;

const HISTORICAL_2024 = {
  kpIndex: 9,
  xrayFlux: 'X5.8',
  geomagneticStatus: 'G5 Extreme',
  dataStatus: 'HISTORICAL MAY 2024',
  dataSource: 'NOAA SWPC May 2024 storm scenario'
};

function airportBox(id, menuId) {
  const input = $(id), menu = $(menuId);
  const render = () => {
    const items = searchAirports(input.value);
    menu.innerHTML = items.map(a => `<button type="button" data-iata="${a.iata}"><b>${a.iata}</b> · ${a.city}<small>${a.name}</small></button>`).join('');
    menu.classList.toggle('show', items.length > 0);
  };
  input.addEventListener('input', render);
  input.addEventListener('focus', render);
  input.addEventListener('blur', () => setTimeout(() => menu.classList.remove('show'), 150));
  menu.addEventListener('mousedown', e => {
    const button = e.target.closest('button');
    if (!button) return;
    const airport = findAirport(button.dataset.iata);
    if (!airport) return;
    input.value = `${airport.city} (${airport.iata})`;
    input.dataset.iata = airport.iata;
    menu.classList.remove('show');
  });
}

function stormReroute(origin, destination) {
  const original = greatCircle(origin, destination, 64);
  const suggested = original.map((p, i) => {
    if (i === 0 || i === original.length - 1) return {...p};
    const t = i / (original.length - 1);
    const bend = Math.sin(Math.PI * t);
    const lat = p.lat;
    // Move the middle of the corridor equatorward so the storm scenario
    // visibly changes the route while preserving both airports.
    const equatorward = Math.sign(lat || 1) * Math.min(Math.abs(lat), 38);
    const shifted = lat + (equatorward - lat) * 0.82 * bend;
    return {lat: shifted, lon: p.lon};
  });
  return {original, suggested};
}

function showRoute() {
  const origin = findAirport($('#sDep').dataset.iata || $('#sDep').value);
  const destination = findAirport($('#sDst').dataset.iata || $('#sDst').value);
  if (!origin || !destination || origin.iata === destination.iata) {
    $('#stormNotice').innerHTML = '<b>Select two different airports</b><br>Choose both airports from the suggestions, then run the simulation.';
    $('#stormNotice').classList.add('show');
    return;
  }

  const {original, suggested} = stormReroute(origin, destination);
  map.clear();
  map.addMarker(origin, 'Departure', '#58c77a', `<b>${origin.city} (${origin.iata})</b>`);
  map.addMarker(destination, 'Destination', '#63b3ff', `<b>${destination.city} (${destination.iata})</b>`);
  map.plotRoute(original, '#3f9fff', 'original', 6);
  map.plotRoute(suggested, '#8cff39', 'suggested', 6, '12 8');
  map.fit([original, suggested]);

  $('#mapTitle').textContent = `${origin.iata} → ${destination.iata} · May 2024 G5 storm route change`;
  $('#stormNotice').innerHTML = `<b>2024 STORM REROUTE SHOWN</b><br>${origin.iata} → ${destination.iata}<br><span class="muted">Blue = original corridor · Green dashed = modeled storm-avoidance corridor · Historical Kp: ${HISTORICAL_2024.kpIndex}</span>`;
  $('#stormNotice').classList.add('show');
}

(async () => {
  airportBox('#sDep', '#sDepMenu');
  airportBox('#sDst', '#sDstMenu');
  map = new MapEngine('stormMap', {center: [30, 30], zoom: 3});
  await map.init();
  $('#stormForm').addEventListener('submit', e => {e.preventDefault(); showRoute();});
  $('#resetStorm').addEventListener('click', () => {
    map.clear();
    $('#stormNotice').classList.remove('show');
    $('#mapTitle').textContent = 'Original route vs 2024 storm reroute';
  });
  showRoute();
})();
