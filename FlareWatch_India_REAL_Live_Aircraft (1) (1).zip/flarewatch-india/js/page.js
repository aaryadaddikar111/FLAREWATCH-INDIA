import { fetchNoaaLive, fetchNoaaKpTrend } from './noaaLive.js';

const $ = selector => document.querySelector(selector);
const REFRESH_MS = 5 * 60 * 1000;
let lastWeather = null;
let lastTrend = [];

function setText(selector, value) {
  const node = $(selector);
  if (node) node.textContent = value;
}

function showLoading() {
  setText('#mode', 'LOADING');
  ['#kp','#xray','#wind','#geo','#proton','#radiation','#bz','#radio','#flare','#density','#updated'].forEach(id => setText(id, 'Loading...'));
}

function showUnavailable() {
  setText('#mode', 'DATA UNAVAILABLE');
  ['#kp','#xray','#wind','#geo','#proton','#radiation','#bz','#radio','#flare','#density'].forEach(id => setText(id, 'Data temporarily unavailable'));
  setText('#updated', 'Retrying automatically');
  lastWeather = null;
  lastTrend = [];
  drawTrend([]);
}

function render(weather) {
  setText('#mode', 'NOAA LIVE');
  setText('#kp', Number.isFinite(weather.kpIndex) ? weather.kpIndex.toFixed(1) : 'Data temporarily unavailable');
  setText('#xray', weather.xrayFlux || 'Data temporarily unavailable');
  setText('#wind', Number.isFinite(weather.solarWindSpeed) ? `${Math.round(weather.solarWindSpeed)} km/s` : 'Data temporarily unavailable');
  setText('#geo', weather.geomagneticStatus || 'Data temporarily unavailable');
  setText('#proton', Number.isFinite(weather.protonFlux) ? `${weather.protonFlux.toFixed(1)} pfu` : 'Data temporarily unavailable');
  setText('#radiation', weather.solarRadiation || 'Data temporarily unavailable');
  setText('#bz', Number.isFinite(weather.bzGsm) ? `${weather.bzGsm.toFixed(1)} nT` : 'Data temporarily unavailable');
  setText('#radio', weather.radioBlackout || 'Data temporarily unavailable');
  setText('#flare', weather.solarFlare || 'Data temporarily unavailable');
  setText('#density', Number.isFinite(weather.solarWindDensity) ? `${weather.solarWindDensity.toFixed(1)} /cm³` : 'Data temporarily unavailable');
  setText('#updated', weather.lastUpdated ? new Date(weather.lastUpdated).toLocaleString() : 'Data temporarily unavailable');

  const observation = weather.timestamp ? new Date(weather.timestamp).toLocaleString() : 'Data temporarily unavailable';
  const note = $('#observationNote');
  if (note) note.textContent = `Latest NOAA observation: ${observation}`;

  lastWeather = weather;
  drawTrend(lastTrend);
}

function drawTrend(rows) {
  const canvas = $('#trend');
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  const W = Math.max(canvas.clientWidth, 280);
  const H = Math.max(canvas.clientHeight, 260);
  canvas.width = Math.round(W * dpr);
  canvas.height = Math.round(H * dpr);
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);

  const pad = { left: 38, right: 18, top: 18, bottom: 32 };
  const plotW = W - pad.left - pad.right;
  const plotH = H - pad.top - pad.bottom;
  const points = (rows || []).filter(p => Number.isFinite(p.kp));

  if (!points.length) {
    ctx.fillStyle = '#707781';
    ctx.font = '12px Inter,system-ui,sans-serif';
    ctx.fillText('K-index data temporarily unavailable', pad.left, pad.top + 24);
    return;
  }

  const yFor = value => pad.top + plotH - (Math.max(0, Math.min(9, value)) / 9) * plotH;
  const xFor = i => points.length === 1 ? pad.left + plotW / 2 : pad.left + (i / (points.length - 1)) * plotW;

  ctx.font = '9px Inter,system-ui,sans-serif';
  for (let k = 0; k <= 9; k += 3) {
    const y = yFor(k);
    ctx.strokeStyle = '#20252b';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad.left, y);
    ctx.lineTo(W - pad.right, y);
    ctx.stroke();
    ctx.fillStyle = '#69717b';
    ctx.textAlign = 'right';
    ctx.fillText(String(k), pad.left - 8, y + 3);
  }

  ctx.beginPath();
  points.forEach((point, index) => {
    const x = xFor(index), y = yFor(point.kp);
    index ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  });
  ctx.strokeStyle = '#ffb400';
  ctx.lineWidth = 3;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.stroke();

  if (points.length > 1) {
    ctx.lineTo(xFor(points.length - 1), pad.top + plotH);
    ctx.lineTo(xFor(0), pad.top + plotH);
    ctx.closePath();
    const gradient = ctx.createLinearGradient(0, pad.top, 0, pad.top + plotH);
    gradient.addColorStop(0, 'rgba(255,180,0,.18)');
    gradient.addColorStop(1, 'rgba(255,180,0,0)');
    ctx.fillStyle = gradient;
    ctx.fill();
  }

  points.forEach((point, index) => {
    const x = xFor(index), y = yFor(point.kp);
    ctx.beginPath();
    ctx.arc(x, y, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#ffb400';
    ctx.fill();
  });

  ctx.fillStyle = '#69717b';
  ctx.textAlign = 'center';
  const labelIndexes = points.length <= 4 ? points.map((_, i) => i) : [0, Math.floor((points.length - 1) / 2), points.length - 1];
  labelIndexes.forEach(index => {
    const date = new Date(points[index].time);
    const label = Number.isNaN(date.getTime()) ? `T${index + 1}` : date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    ctx.fillText(label, xFor(index), H - 10);
  });

  const latest = points[points.length - 1].kp;
  ctx.textAlign = 'left';
  ctx.font = '800 11px Inter,system-ui,sans-serif';
  ctx.fillStyle = '#ffb400';
  ctx.fillText(`CURRENT Kp ${latest.toFixed(1)}`, pad.left, pad.top + 12);
}

async function loadLiveData() {
  showLoading();
  try {
    const [weather, trend] = await Promise.all([fetchNoaaLive(), fetchNoaaKpTrend()]);
    lastTrend = trend;
    render(weather);
  } catch (error) {
    console.error('NOAA SWPC live-data request failed:', error);
    showUnavailable();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadLiveData();
  $('#refresh')?.addEventListener('click', loadLiveData);
  setInterval(loadLiveData, REFRESH_MS);
  window.addEventListener('resize', () => drawTrend(lastTrend));
});
