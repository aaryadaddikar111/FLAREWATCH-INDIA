export class MapEngine{
 constructor(id,options={}){this.id=id;this.options=options;this.map=null;this.layers={};this.clickHandler=null;}
 async init(){
   if(!window.L) throw new Error('Leaflet did not load');
   this.map=L.map(this.id,{zoomControl:true,worldCopyJump:true}).setView(this.options.center||[25,55],this.options.zoom||3);
   L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'&copy; OpenStreetMap contributors'}).addTo(this.map);
   this.layers.original=L.layerGroup().addTo(this.map);
   this.layers.suggested=L.layerGroup().addTo(this.map);
   this.layers.risk=L.layerGroup().addTo(this.map);
   this.layers.points=L.layerGroup().addTo(this.map);
   this.layers.radiation=L.layerGroup().addTo(this.map);
   window.__mapEngine=this;
   return this;
 }
 clear(){Object.values(this.layers).forEach(l=>l.clearLayers());}
 plotRoute(path,color,layer='original',weight=5,dash=null){
   const line=L.polyline(path.map(p=>[p.lat,p.lon]),{color,weight,opacity:.95,dashArray:dash||null,lineCap:'round',lineJoin:'round'}).addTo(this.layers[layer]);
   return line;
 }
 riskPalette(){
   const css=getComputedStyle(document.documentElement);
   return {
     LOW:css.getPropertyValue('--risk-low').trim(),
     MODERATE:css.getPropertyValue('--risk-mild').trim(),
     HIGH:css.getPropertyValue('--risk-moderate').trim(),
     SEVERE:css.getPropertyValue('--risk-high').trim()
   };
 }
 plotRiskRoute(path,segments,layer='original',weight=5,dash=null){
   if(!path?.length||!segments?.length)return;
   const colors=this.riskPalette();
   for(let i=1;i<path.length;i++){
     const a=path[i-1],b=path[i];
     const seg=segments[Math.min(i-1,segments.length-1)]||segments[segments.length-1];
     const risk=seg?.risk||'LOW';
     const color=colors[risk]||colors.LOW;
     const label=risk==='MODERATE'?'MILD':risk;
     L.polyline([[a.lat,a.lon],[b.lat,b.lon]],{
       color,weight,opacity:.98,dashArray:dash||null,lineCap:'round',lineJoin:'round'
     }).bindTooltip(`${label} exposure · ${Number(seg?.exposure||0).toFixed(0)}/100`).addTo(this.layers[layer]);
   }
 }
 plotRiskZones(segments){
   const colors=this.riskPalette();
   segments.forEach(p=>{
     const color=colors[p.risk]||colors.LOW;
     const label=p.risk==='MODERATE'?'MILD':p.risk;
     L.circle([p.lat,p.lon],{radius:p.risk==='SEVERE'?220000:p.risk==='HIGH'?150000:p.risk==='MODERATE'?100000:70000,color,fillColor:color,fillOpacity:.10,weight:1,opacity:.35}).bindTooltip(`${label} exposure · ${p.exposure.toFixed(0)}/100`).addTo(this.layers.risk);
   });
 }
 plotRadiation(segments){
   segments.filter((p,i)=>i%3===0).forEach(p=>{
     const color=p.radiationRisk==='HIGH'?'#ff493d':p.radiationRisk==='MODERATE'?'#ff9d00':'#63b3ff';
     L.circleMarker([p.lat,p.lon],{radius:5,color,fillColor:color,fillOpacity:.85,weight:1}).bindTooltip(`Radiation indicator: ${p.radiationRisk}`).addTo(this.layers.radiation);
   });
 }
 addMarker(point,label,color='#63b3ff',popup=''){
   const icon=L.divIcon({className:'fw-marker',html:`<span style="background:${color};box-shadow:0 0 0 4px ${color}33,0 0 16px ${color}"></span>`,iconSize:[14,14],iconAnchor:[7,7]});
   return L.marker([point.lat,point.lon],{icon}).bindPopup(popup||label).addTo(this.layers.points);
 }
 fit(paths){const all=paths.flat().map(p=>[p.lat,p.lon]); if(all.length)this.map.fitBounds(L.latLngBounds(all),{padding:[35,35]});}
 onClick(fn){this.clickHandler=fn;this.map.on('click',e=>this.clickHandler?.({lat:e.latlng.lat,lon:e.latlng.lng}));}
 setLayer(name,visible){if(visible&&!this.map.hasLayer(this.layers[name]))this.layers[name].addTo(this.map);if(!visible&&this.map.hasLayer(this.layers[name]))this.map.removeLayer(this.layers[name]);}
}
