import {fetchSpaceWeather,normalizeDemo} from './api.js';
import {DEMO} from '../data/demoData.js';
import {MapEngine} from './mapEngine.js';
import {findAirport} from './routeEngine.js';
import {suggestDronePath,routeMetrics} from './operationalModel.js';

const $=s=>document.querySelector(s),n=s=>Number($(s).value)||0;
let wx,map,path=[],analysis;
let droneMarker=null,trailLine=null,autoFollow=false,telemetryTimer=null,realTelemetry=false;
let telemetry={lat:19.076,lon:72.877,altitude:120,satellites:12,heading:90};

function locationPoint(){const q=$('#location').value.trim(),a=findAirport(q);return a?{lat:a.lat,lon:a.lon,city:a.city}:{lat:19.076,lon:72.877,city:q||'Mission Area'}}
function makeDefaultPath(c,r){const d=Math.max(0.5,r)/111;return[{lat:c.lat,lon:c.lon},{lat:c.lat+d*.55,lon:c.lon+d*.7},{lat:c.lat+d*.2,lon:c.lon+d*1.1},{lat:c.lat-d*.25,lon:c.lon+d*.6}]}
function profile(){return{altitude:n('#altitude'),missionDuration:n('#duration'),operatingRadius:n('#radius'),operationType:$('#operation').value,droneType:$('#droneType').value,navigationSystem:$('#nav').value,gnssDependency:$('#gnss').value,receiverType:$('#receiver').value,augmentation:$('#augment').value,communicationSystem:$('#comm').value,backupNavigation:$('#backup').value,returnToHome:$('#rth').value,missionCriticality:$('#critical').value}}
function setWx(){const live=!String(wx.dataStatus).includes('DEMO')&&!String(wx.dataStatus).includes('SIMULATION');$('#status').innerHTML=`<span class="dot ${live?'live':'error'}"></span>${wx.dataStatus}`;$('#mode').textContent=wx.dataStatus;$('#kp').textContent=Number.isFinite(wx.kpIndex)?wx.kpIndex.toFixed(1):'—';$('#xray').textContent=wx.xrayFlux||'—';$('#wind').textContent=Number.isFinite(wx.solarWindSpeed)?Math.round(wx.solarWindSpeed)+' km/s':'—';$('#geo').textContent=wx.geomagneticStatus||'—'}
function fmt(h){const m=Math.round(h*60);return`${Math.floor(m/60)}h ${String(m%60).padStart(2,'0')}m`}
function riskTextClass(risk){return risk==='SEVERE'?'risk-high-text':risk==='HIGH'?'risk-moderate-text':risk==='MODERATE'?'risk-mild-text':'risk-low-text'}
function riskLabel(risk){return risk==='SEVERE'?'High':risk==='HIGH'?'Moderate':risk==='MODERATE'?'Mild':'Low'}
function disturbanceLabel(kp){if(!Number.isFinite(kp))return'Unavailable';if(kp>=7)return'Strong';if(kp>=5)return'Moderate';if(kp>=4)return'Unsettled';return'Low'}
function tecEstimate(kp){
  // NOAA SWPC does not expose a live global TEC value in the current feeds used by this app.
  // Keep this clearly labelled as a model estimate derived from the live Kp condition.
  if(!Number.isFinite(kp))return'—';
  return (18+kp*1.7).toFixed(1);
}
function setRiskChip(id,risk){const el=$('#'+id);if(!el)return;el.textContent=riskLabel(risk);el.className=`risk-chip ${riskTextClass(risk)}`}
function renderDroneInsights(){
  if(!wx||!analysis)return;
  const peak=analysis.originalScore?.peak||{};
  const overall=analysis.originalScore?.score??0;
  const routeRisk=analysis.originalScore?.risk||'LOW';
  const gnssRisk=peak.gnssRisk||'LOW';
  const commRisk=peak.communicationRisk||'LOW';
  const routeScore=Math.max(0,Math.min(5,overall/20));
  const gnssScore=Math.max(0,Math.min(5,(peak.gnss??0)/20));
  const commScore=Math.max(0,Math.min(5,(peak.communication??0)/20));
  const operational=Math.max(routeScore,gnssScore,commScore);
  const operationalRisk=operational>=3.75?'SEVERE':operational>=2.5?'HIGH':operational>=1.25?'MODERATE':'LOW';

  $('#droneTec').textContent=tecEstimate(wx.kpIndex);
  $('#droneDisturbance').textContent=disturbanceLabel(wx.kpIndex);
  $('#droneGnssSensitivity').textContent=riskLabel(gnssRisk);
  $('#droneGnssSensitivity').className=riskTextClass(gnssRisk);

  const factors=[];
  if(Number.isFinite(wx.xrayWatts)) factors.push(`Solar X-ray activity (${wx.xrayFlux}) is ${wx.xrayWatts>=1e-5?'elevated':'within lower activity bands'}.`);
  if(Number.isFinite(wx.solarWindSpeed)) factors.push(`Solar-wind speed is ${Math.round(wx.solarWindSpeed)} km/s, affecting modeled geomagnetic sensitivity.`);
  if(Number.isFinite(wx.bzGsm)) factors.push(`IMF Bz is ${wx.bzGsm.toFixed(1)} nT; southward values increase modeled ionospheric exposure.`);
  if(Number.isFinite(wx.kpIndex)) factors.push(`GNSS dependency is reflected in the navigation-risk calculation; live Kp is ${wx.kpIndex.toFixed(1)}.`);
  factors.push(`Mission altitude: ${profile().altitude} m.`);
  $('#liveFactorList').innerHTML=factors.slice(0,5).map(x=>`<li>${x}</li>`).join('');

  setRiskChip('droneRouteRisk',routeRisk);$('#droneRouteScore').textContent=`${routeScore.toFixed(1)} / 5`;
  setRiskChip('droneGnssRisk',gnssRisk);$('#droneGnssScore').textContent=`${gnssScore.toFixed(1)} / 5`;
  setRiskChip('droneCommRisk',commRisk);$('#droneCommScore').textContent=`${commScore.toFixed(1)} / 5`;
  setRiskChip('droneOverallRisk',operationalRisk);$('#droneOverallScore').textContent=`${operational.toFixed(1)} / 5`;
  $('#droneExposurePill').textContent=`${riskLabel(operationalRisk).toUpperCase()} · LIVE MODEL`;

  renderForecast();
}
function renderForecast(){
  const forecast=Array.isArray(wx?.forecast)?wx.forecast.filter(x=>Number.isFinite(Number(x.kp))).slice(0,4):[];
  const fallback=forecast.length?forecast:(Array.isArray(wx?.history)?wx.history.slice(-4).map(x=>({kp:Number(x.kp),time:x.time})):[]);
  if(!fallback.length){$('#droneForecastTimeline').innerHTML='<div class="timeline-empty">NOAA Kp forecast temporarily unavailable.</div>';return}
  const html=fallback.map((item,i)=>{
    const kp=Number(item.kp);const risk=kp>=7?'SEVERE':kp>=5?'HIGH':kp>=4?'MODERATE':'LOW';
    const label=riskLabel(risk);const cls=riskTextClass(risk);
    let time='Now';
    if(i>0&&item.time){const d=new Date(item.time);time=Number.isFinite(d.getTime())?d.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'}):`${i*10} min`;}
    return `<div class="timeline-point"><div class="timeline-time">${time}</div><div class="timeline-dot ${cls}" style="color:var(--${risk==='LOW'?'risk-low':risk==='MODERATE'?'risk-mild':risk==='HIGH'?'risk-moderate':'risk-high'})"></div><div class="timeline-risk ${cls}">${label}</div><div class="timeline-kp">Kp ${kp.toFixed(1)}</div></div>`;
  }).join('');
  $('#droneForecastTimeline').innerHTML=`<div class="timeline-line"></div><div class="timeline-points">${html}</div>`;
}

function riskClass(risk){return risk==='SEVERE'?'high':risk==='HIGH'?'moderate':risk==='MODERATE'?'mild':'low'}
function render(){
  const p=profile();
  const r=suggestDronePath(path,wx,p);analysis={...r,profile:p};
  renderDroneInsights();
  const om=routeMetrics(r.original,p,'Drone'),sm=routeMetrics(r.suggested,p,'Drone');
  const reduction=r.originalScore.score?Math.max(0,(r.originalScore.score-r.suggestedScore.score)/r.originalScore.score*100):0;
  const peak=r.originalScore.peak;
  $('#routeStatus').textContent=r.rerouted?'SUGGESTED PATH RECOMMENDED':'ORIGINAL PATH ACCEPTABLE';
  $('#routeStatus').className=`status-banner ${r.rerouted?'warn':'ok'}`;
  $('#origDistance').textContent=om.distance.toFixed(2)+' km';$('#sugDistance').textContent=sm.distance.toFixed(2)+' km';
  $('#origTime').textContent=fmt(om.hours);$('#sugTime').textContent=fmt(sm.hours);
  $('#distanceDiff').textContent=`+${Math.max(0,sm.distance-om.distance).toFixed(2)} km`;$('#timeDiff').textContent=`+${fmt(Math.max(0,sm.hours-om.hours))}`;
  $('#peakRisk').textContent=peak.risk;$('#peakRisk').style.color=peak.risk==='SEVERE'?'#ff493d':peak.risk==='HIGH'?'#ff9d00':peak.risk==='MODERATE'?'#ffd166':'#58c77a';
  $('#peakAltitude').textContent=p.altitude+' m';$('#peakGnss').textContent=peak.gnssRisk;$('#peakComm').textContent=peak.communicationRisk;
  $('#peakReason').innerHTML=(r.rerouted?r.reasons:['No significant modeled exposure difference requires a reroute.']).map(x=>`<div>• ${x}</div>`).join('');
  $('#rthReason').textContent=p.returnToHome==='Disabled'?'Return-to-home is disabled; recovery resilience is reduced.':'Return-to-home/failsafe is configured.';
  $('#riskSummary').textContent=r.originalScore.risk;$('#riskSummary2').textContent=r.suggestedScore.risk;
  $('#radOriginal').textContent=peak.radiationRisk;$('#radSuggested').textContent=r.suggestedScore.peak.radiationRisk;
  $('#riskReduction').textContent=r.rerouted?reduction.toFixed(1)+'%':'0%';
  $('#energyOriginal').textContent=om.energy==null?'Estimate unavailable':om.energy.toFixed(1)+' Wh/km-model';$('#energySuggested').textContent=sm.energy==null?'Estimate unavailable':sm.energy.toFixed(1)+' Wh/km-model';
  $('#results').classList.add('show');

  const c=locationPoint();
  map.clear();
  map.addMarker(c,'Mission area','#ffb400',`<b>${c.city}</b><br>Mission center`);
  // Keep the existing risk zones, while making the mission path visually match the reference:
  // each segment uses the calculated space-weather exposure band.
  map.plotRiskRoute(r.original,r.originalScore.points,'original',6);
  if(r.rerouted)map.plotRoute(r.suggested,'#8cff39','suggested',5,'10 8');
  map.plotRiskZones(r.originalScore.points);map.plotRadiation(r.originalScore.points);
  map.fit([r.original,r.suggested]);
  drawDrone();
}

function readTelemetryInputs(){
  telemetry.lat=Number($('#telemetryLat').value)||19.076;
  telemetry.lon=Number($('#telemetryLon').value)||72.877;
  telemetry.altitude=n('#altitude')||120;
  telemetry.satellites=Math.max(0,Math.round(n('#gpsSatellites')||12));
  telemetry.heading=90;
}
function droneIcon(){
  return L.divIcon({className:'fw-drone-icon',html:`<div class="drone-craft" style="transform:rotate(${telemetry.heading}deg)"><span class="drone-wing"></span><span class="drone-body">🛸</span></div>`,iconSize:[38,38],iconAnchor:[19,19]});
}
function telemetryPopup(){
  const id=$('#droneId').value.trim()||'FW-DRONE-01';
  return `<div class="drone-popup"><b>${id}</b><span>DEMO TELEMETRY</span><hr><div>Latitude <strong>${telemetry.lat.toFixed(6)}</strong></div><div>Longitude <strong>${telemetry.lon.toFixed(6)}</strong></div><div>Altitude <strong>${telemetry.altitude.toFixed(0)} m</strong></div><div>GPS satellites <strong>${telemetry.satellites}</strong></div><div>Heading <strong>${Math.round(telemetry.heading)}°</strong></div></div>`;
}
function updateTelemetryUI(){
  $('#telemetryDroneId').textContent=$('#droneId').value.trim()||'FW-DRONE-01';
  $('#liveLat').textContent=telemetry.lat.toFixed(6);$('#liveLon').textContent=telemetry.lon.toFixed(6);$('#liveAlt').textContent=`${telemetry.altitude.toFixed(0)} m`;$('#liveSats').textContent=telemetry.satellites;$('#liveHeading').textContent=`${Math.round(telemetry.heading)}°`;$('#liveStatus').textContent='MOVING';
}
function drawDrone(){
  if(!map?.map)return;
  const point=[telemetry.lat,telemetry.lon];
  if(!droneMarker){
    droneMarker=L.marker(point,{icon:droneIcon(),zIndexOffset:1200}).addTo(map.map);
    droneMarker.bindPopup(telemetryPopup());
  }else{droneMarker.setLatLng(point);droneMarker.setIcon(droneIcon());droneMarker.setPopupContent(telemetryPopup());}
  if(!trailLine){trailLine=L.polyline([point],{color:'#ffb400',weight:3,opacity:.9,dashArray:'5 6',lineCap:'round'}).addTo(map.map);}
  const current=trailLine.getLatLngs();
  const last=current[current.length-1];
  if(!last || last.lat!==telemetry.lat || last.lng!==telemetry.lon)trailLine.addLatLng(point);
  updateTelemetryUI();
  if(autoFollow)map.map.panTo(point,{animate:true,duration:.5});
}
window.__setDroneTelemetry=(data={})=>{
  realTelemetry=true;
  if(Number.isFinite(Number(data.lat)))telemetry.lat=Number(data.lat);
  if(Number.isFinite(Number(data.lon)))telemetry.lon=Number(data.lon);
  if(Number.isFinite(Number(data.altitude)))telemetry.altitude=Number(data.altitude);
  if(Number.isFinite(Number(data.satellites)))telemetry.satellites=Math.round(Number(data.satellites));
  if(Number.isFinite(Number(data.heading)))telemetry.heading=Number(data.heading);
  drawDrone();
};

function simulateTelemetry(){
  if(realTelemetry)return;
  // Demo-only movement around Mumbai. The same state can later be replaced by
  // a real telemetry adapter that supplies lat/lon/heading/altitude/satellites.
  const t=Date.now()/1000;
  const radiusLat=.018,radiusLon=.023;
  const phase=t*.11;
  const prevLat=telemetry.lat,prevLon=telemetry.lon;
  telemetry.lat=19.076+Math.sin(phase)*radiusLat;
  telemetry.lon=72.877+Math.cos(phase)*radiusLon;
  const dLon=telemetry.lon-prevLon,dLat=telemetry.lat-prevLat;
  if(Math.abs(dLon)+Math.abs(dLat)>0)telemetry.heading=(Math.atan2(dLon,dLat)*180/Math.PI+360)%360;
  telemetry.altitude=n('#altitude')||120;
  telemetry.satellites=Math.max(0,Math.round(n('#gpsSatellites')||12));
  drawDrone();
}

(async()=>{
  try{wx=await fetchSpaceWeather()}catch{wx=normalizeDemo(DEMO.elevated)}
  setWx();
  map=new MapEngine('droneMap',{center:[19,73],zoom:11});await map.init();
  readTelemetryInputs();
  path=makeDefaultPath(locationPoint(),n('#radius')||5);

  $('#draw').addEventListener('click',()=>{path=[];map.clear();$('#draw').textContent='CLICK MAP TO ADD WAYPOINTS · DONE';map.onClick(pt=>{path.push(pt);map.plotRoute(path,'#3f9fff','original',5);map.addMarker(pt,'Waypoint','#3f9fff',`Waypoint ${path.length}`)})});
  $('#clearPath').addEventListener('click',()=>{path=makeDefaultPath(locationPoint(),n('#radius')||5);render()});
  $('#location').addEventListener('change',()=>{path=makeDefaultPath(locationPoint(),n('#radius')||5);map.map.setView([path[0].lat,path[0].lon],11)});
  $('#droneId').addEventListener('input',()=>{updateTelemetryUI();if(droneMarker)droneMarker.setPopupContent(telemetryPopup())});
  ['telemetryLat','telemetryLon','gpsSatellites','altitude'].forEach(id=>$('#'+id)?.addEventListener('change',()=>{readTelemetryInputs();drawDrone()}));
  $('#centerDrone').addEventListener('click',()=>map.map.setView([telemetry.lat,telemetry.lon],13,{animate:true}));
  $('#autoFollow').addEventListener('click',()=>{autoFollow=!autoFollow;$('#autoFollow').textContent=`AUTO FOLLOW: ${autoFollow?'ON':'OFF'}`;$('#autoFollow').classList.toggle('active',autoFollow);if(autoFollow)map.map.panTo([telemetry.lat,telemetry.lon],{animate:true})});
  $('#droneForm').addEventListener('submit',e=>{e.preventDefault();readTelemetryInputs();render()});
  render();
  telemetryTimer=setInterval(simulateTelemetry,1200);
  setInterval(async()=>{try{wx=await fetchSpaceWeather();setWx();if(analysis)render()}catch{/* keep last known NOAA state */}},60000);
})();
