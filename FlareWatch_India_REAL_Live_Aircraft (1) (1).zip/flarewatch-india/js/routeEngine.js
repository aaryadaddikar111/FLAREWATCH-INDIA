const R=6371;
const deg=r=>r*Math.PI/180;
const rad=r=>r*180/Math.PI;

export const AIRPORTS=[
 {name:'Chhatrapati Shivaji Maharaj International Airport',city:'Mumbai',iata:'BOM',icao:'VABB',lat:19.0896,lon:72.8656},
 {name:'Indira Gandhi International Airport',city:'Delhi',iata:'DEL',icao:'VIDP',lat:28.5562,lon:77.1000},
 {name:'Kempegowda International Airport',city:'Bengaluru',iata:'BLR',icao:'VOBL',lat:13.1986,lon:77.7066},
 {name:'Chennai International Airport',city:'Chennai',iata:'MAA',icao:'VOMM',lat:12.9941,lon:80.1709},
 {name:'Rajiv Gandhi International Airport',city:'Hyderabad',iata:'HYD',icao:'VOHS',lat:17.2403,lon:78.4294},
 {name:'Pune Airport',city:'Pune',iata:'PNQ',icao:'VAPO',lat:18.5821,lon:73.9197},
 {name:'Netaji Subhas Chandra Bose International Airport',city:'Kolkata',iata:'CCU',icao:'VECC',lat:22.6547,lon:88.4467},
 {name:'Cochin International Airport',city:'Kochi',iata:'COK',icao:'VOCI',lat:10.1520,lon:76.4019},
 {name:'Ahmedabad Airport',city:'Ahmedabad',iata:'AMD',icao:'VAAH',lat:23.0772,lon:72.6347},
 {name:'Goa International Airport',city:'Goa',iata:'GOX',icao:'VOGA',lat:15.3808,lon:73.8314},
 {name:'Heathrow Airport',city:'London',iata:'LHR',icao:'EGLL',lat:51.4700,lon:-0.4543},
 {name:'Gatwick Airport',city:'London',iata:'LGW',icao:'EGKK',lat:51.1537,lon:-0.1821},
 {name:'John F. Kennedy International Airport',city:'New York',iata:'JFK',icao:'KJFK',lat:40.6413,lon:-73.7781},
 {name:'Los Angeles International Airport',city:'Los Angeles',iata:'LAX',icao:'KLAX',lat:33.9416,lon:-118.4085},
 {name:'Chicago O’Hare International Airport',city:'Chicago',iata:'ORD',icao:'KORD',lat:41.9742,lon:-87.9073},
 {name:'San Francisco International Airport',city:'San Francisco',iata:'SFO',icao:'KSFO',lat:37.6213,lon:-122.3790},
 {name:'Dubai International Airport',city:'Dubai',iata:'DXB',icao:'OMDB',lat:25.2532,lon:55.3657},
 {name:'Doha Hamad International Airport',city:'Doha',iata:'DOH',icao:'OTHH',lat:25.2731,lon:51.6081},
 {name:'Singapore Changi Airport',city:'Singapore',iata:'SIN',icao:'WSSS',lat:1.3644,lon:103.9915},
 {name:'Tokyo Haneda Airport',city:'Tokyo',iata:'HND',icao:'RJTT',lat:35.5494,lon:139.7798},
 {name:'Sydney Kingsford Smith Airport',city:'Sydney',iata:'SYD',icao:'YSSY',lat:-33.9399,lon:151.1753},
 {name:'Frankfurt Airport',city:'Frankfurt',iata:'FRA',icao:'EDDF',lat:50.0379,lon:8.5622},
 {name:'Paris Charles de Gaulle Airport',city:'Paris',iata:'CDG',icao:'LFPG',lat:49.0097,lon:2.5479},
 {name:'Amsterdam Schiphol Airport',city:'Amsterdam',iata:'AMS',icao:'EHAM',lat:52.3105,lon:4.7683},
 {name:'Istanbul Airport',city:'Istanbul',iata:'IST',icao:'LTFM',lat:41.2753,lon:28.7519},
 {name:'Johannesburg O.R. Tambo International Airport',city:'Johannesburg',iata:'JNB',icao:'FAOR',lat:-26.1367,lon:28.2411},
 {name:'São Paulo–Guarulhos International Airport',city:'São Paulo',iata:'GRU',icao:'SBGR',lat:-23.4356,lon:-46.4731},
 {name:'Toronto Pearson International Airport',city:'Toronto',iata:'YYZ',icao:'CYYZ',lat:43.6777,lon:-79.6248},
 {name:'Vancouver International Airport',city:'Vancouver',iata:'YVR',icao:'CYVR',lat:49.1967,lon:-123.1815},
 {name:'Anchorage International Airport',city:'Anchorage',iata:'ANC',icao:'PANC',lat:61.1743,lon:-149.9985},
 {name:'Reykjavík Keflavík Airport',city:'Reykjavik',iata:'KEF',icao:'BIKF',lat:63.9850,lon:-22.6056}
];

export function searchAirports(q=''){
 const s=q.trim().toLowerCase(); if(!s)return AIRPORTS.slice(0,8);
 return AIRPORTS.filter(a=>`${a.iata} ${a.icao} ${a.city} ${a.name}`.toLowerCase().includes(s)).slice(0,8);
}
export function findAirport(q){
 const s=q.trim().toLowerCase();
 return AIRPORTS.find(a=>[a.iata,a.icao,a.city,a.name].some(v=>v.toLowerCase()===s)) || AIRPORTS.find(a=>`${a.iata} ${a.city}`.toLowerCase().includes(s));
}

function interpolate(a,b,t){
 const p1=deg(a.lat), l1=deg(a.lon), p2=deg(b.lat), l2=deg(b.lon);
 const d=2*Math.asin(Math.sqrt(Math.sin((p2-p1)/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin((l2-l1)/2)**2));
 if(d===0)return {...a};
 const A=Math.sin((1-t)*d)/Math.sin(d), B=Math.sin(t*d)/Math.sin(d);
 const x=A*Math.cos(p1)*Math.cos(l1)+B*Math.cos(p2)*Math.cos(l2);
 const y=A*Math.cos(p1)*Math.sin(l1)+B*Math.cos(p2)*Math.sin(l2);
 const z=A*Math.sin(p1)+B*Math.sin(p2);
 return {lat:rad(Math.atan2(z,Math.sqrt(x*x+y*y))),lon:rad(Math.atan2(y,x))};
}
export function greatCircle(a,b,steps=40){
 return Array.from({length:steps+1},(_,i)=>interpolate(a,b,i/steps));
}
export function haversine(a,b){
 const p1=deg(a.lat),p2=deg(b.lat),dp=deg(b.lat-a.lat),dl=deg(b.lon-a.lon);
 const h=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
 return R*2*Math.atan2(Math.sqrt(h),Math.sqrt(1-h));
}
export function pathDistance(path){return path.reduce((s,p,i)=>i?s+haversine(path[i-1],p):0,0)}

export function createSuggestedRoute(origin,destination,wx,profile){
 const original=greatCircle(origin,destination,48);
 const kp=Number(wx?.kpIndex)||0;
 const polarSensitivity=(profile?.polarExposure==='High'?1.2:profile?.polarExposure==='Medium'?0.65:0.25);
 const needsAvoid=kp>=4.8 || polarSensitivity>1;
 if(!needsAvoid) return {original,suggested:original,rerouted:false,reason:[]};
 const maxLat=Math.max(Math.abs(origin.lat),Math.abs(destination.lat));
 const targetCap=Math.max(35, Math.min(48, 50 - Math.max(0,kp-4)*2 - polarSensitivity*2));
 const pts=[];
 for(let i=0;i<original.length;i++){
   const p=original[i];
   const t=i/(original.length-1);
   const blend=Math.sin(Math.PI*t);
   let lat=p.lat;
   if(Math.abs(p.lat)>targetCap){
     const sign=p.lat>=0?1:-1;
     lat=sign*(targetCap + (Math.abs(p.lat)-targetCap)*(1-blend)*0.15);
     lat=sign*Math.min(Math.abs(lat),targetCap);
   }
   pts.push({lat,lon:p.lon});
 }
 // Ensure the alternative remains a smooth corridor and doesn't alter endpoints.
 pts[0]=original[0]; pts[pts.length-1]=original[original.length-1];
 const suggested=[pts[0]];
 for(let i=1;i<pts.length;i+=2)suggested.push(pts[i]);
 if(suggested.at(-1)!==pts.at(-1))suggested.push(pts.at(-1));
 return {original,suggested,rerouted:true,reason:[
   `Original route reaches approximately ${Math.round(maxLat)}° latitude.`,
   `Current Kp ${kp.toFixed(1)} increases modeled geomagnetic exposure.`,
   'High-latitude segments are more sensitive to the prototype GNSS/communication exposure model.',
   'Suggested corridor reduces modeled high-latitude exposure while keeping the endpoints unchanged.'
 ]};
}

export function routeSegments(path,wx,profile){
 const kp=Number(wx?.kpIndex)||0;
 return path.map((p,i)=>{
   const lat=Math.abs(p.lat);
   const polar=Math.max(0,(lat-45)/35);
   const altFactor=Math.min(1.3,Math.max(0.1,(Number(profile?.cruiseAltitude)||35000)/45000));
   const gnss={Low:0.6,Medium:1,High:1.35}[profile?.gnssDependency||'Medium']||1;
   const comm=(profile?.communicationSystem||'').includes('HF')?1.2:1;
   const exposure=Math.max(0, Math.min(100, kp*7 + polar*34*gnss + altFactor*8 + comm*3));
   const risk=exposure>=70?'SEVERE':exposure>=48?'HIGH':exposure>=28?'MODERATE':'LOW';
   const radiation=Math.max(0,Math.min(100,kp*6+polar*42+altFactor*12));
   const radiationRisk=radiation>=70?'HIGH':radiation>=40?'MODERATE':'LOW';
   return {...p,index:i,exposure,risk,radiation,radiationRisk};
 });
}

export function summarizeRoute(path,profile){
 const distance=pathDistance(path);
 const hours=Number(profile?.flightDuration)||Math.max(1,distance/820);
 const speed=distance/hours;
 return {distance,hours,speed};
}

const fuelRate={
 'Commercial Jet':7.9,'Business Jet':5.2,'Turboprop':2.4,'Military / Special Mission':8.6,'Other':6.5
};
export function estimateFuel(distance,aircraft){
 const rate=fuelRate[aircraft]||fuelRate.Other;
 return distance*rate;
}
export function routeStats(path,profile){
 const s=summarizeRoute(path,profile); const fuel=estimateFuel(s.distance,profile.aircraftType);
 return {distance:s.distance,hours:s.hours,fuel};
}
export function pct(a,b){return a?((b-a)/a)*100:0}

export function suggestedAltitude(current,wx,profile){
 const kp=Number(wx?.kpIndex)||0;
 if(kp<5) return {value:current,changed:false,reason:'Current modeled exposure does not justify an altitude change.'};
 const target=Math.max(28000,Math.round((current-2000)/1000)*1000);
 return {value:target,changed:target!==current,reason:target!==current?'Model estimates lower exposure at the suggested altitude under the current conditions.':'No altitude adjustment recommended.'};
}

export function overallPositionRisk(point,wx,profile){
 const s=routeSegments([point],wx,profile)[0];
 return {risk:s.risk,exposure:s.exposure,radiationRisk:s.radiationRisk,gnssRisk:s.exposure>=60?'HIGH':s.exposure>=35?'MODERATE':'LOW',communicationRisk:(profile?.communicationSystem||'').includes('HF')&&s.exposure>35?'HIGH':s.exposure>55?'MODERATE':'LOW'};
}
