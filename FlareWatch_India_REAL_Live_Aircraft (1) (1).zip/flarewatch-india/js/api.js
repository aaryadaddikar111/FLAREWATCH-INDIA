import { fetchNoaaLive, fetchNoaaAlerts, fetchNoaaKpForecast, normalizeNoaaLive, NOAA_LIVE_ENDPOINTS } from './noaaLive.js';

export const ENDPOINTS = NOAA_LIVE_ENDPOINTS;

export async function fetchSpaceWeather() {
  const weather = await fetchNoaaLive();
  try {
    weather.forecast = await fetchNoaaKpForecast();
  } catch {
    weather.forecast = [];
  }
  return weather;
}

export async function fetchAlerts() {
  return fetchNoaaAlerts();
}

// Kept for simulator/testing/fallback paths only. Live Space Weather does not call this.
export function normalizeDemo(data) {
  return { ...data, timestamp: new Date().toISOString() };
}

export { normalizeNoaaLive };
