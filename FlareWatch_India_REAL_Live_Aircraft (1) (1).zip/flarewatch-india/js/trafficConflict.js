import {AIRPORTS, greatCircle, haversine} from './routeEngine.js';
import {MapEngine} from './mapEngine.js';
import {fetchLiveAircraft} from './liveTraffic.js';

const $=s=>document.querySelector(s);

// A handful of short local waypoints so drone corridors have somewhere
// plausible to plot alongside long-haul flight corridors. Prototype
// coordinates only — not real operational waypoints.
const DRONE_POINTS=[
  {name:'Mumbai — BKC Sector',iata:'BKC',city:'Mumbai',lat:19.0596,lon:72.8656},
  {name:'Mumbai — Juhu Coastline',iata:'JUHU',city:'Mumbai',lat:19.0989,lon:72.8265},
  {name:'Mumbai — Powai Corridor',iata:'PWAI',city:'Mumbai',lat:19.1197,lon:72.9050},
  {name:'Mumbai — Bandra Waypoint',iata:'BNDR',city:'Mumbai',lat:19.0544,lon:72.8402},
  {name:'Navi Mumbai — Airport Approach',iata:'NMIA',city:'Navi Mumbai',lat:19.0918,lon:73.0169}
];
const LOCATIONS=[...AIRPORTS,...DRONE_POINTS];
function findLoc(iata){return LOCATIONS.find(a=>a.iata===iata);}

const PALETTE=['#ffd400','#ff9d00','#8affa0','#ff493d','#63b3ff','#ff6bd6','#9be56f','#58d6ff'];
let colorIndex=0;
function nextColor(){const c=PALETTE[colorIndex%PALETTE.length];colorIndex++;return c;}

let routes=[], routeSeq=1, map, conflictMarkers=[];
let liveLayer, liveMarkers=[], liveTimer=null, liveInFlight=false;
const LIVE_REFRESH_MS=45000;

function planeIcon(headingDeg,color){
  const rot=Number.isFinite(headingDeg)?headingDeg:0;
  return L.divIcon({
    className:'fw-plane-icon',
    html:`<div style="transform:rotate(${rot}deg);width:22px;height:22px;display:flex;align-items:center;justify-content:center;filter:drop-shadow(0 0 5px ${color})"><svg viewBox="0 0 24 24" width="18" height="18"><path d="M12 2 L15 11 L22 14 L15 15.5 L14 22 L12 18.5 L10 22 L9 15.5 L2 14 L9 11 Z" fill="${color}"/></svg></div>`,
    iconSize:[22,22], iconAnchor:[11,11]
  });
}

function fmtAlt(ft){return Number.isFinite(ft)?ft.toLocaleString()+' ft':'—';}
function fmtSpeed(kt){return Number.isFinite(kt)?Math.round(kt*1.852)+' km/h':'—';}
function fmtAge(sec){return Number.isFinite(sec)?(sec<60?`${Math.round(sec)}s ago`:`${Math.round(sec/60)}m ago`):'age unavailable';}

async function refreshLiveTraffic(){
  if(liveInFlight)return;
  liveInFlight=true;
  const statusEl=$('#liveTrafficStatus');
  try{
    const {timestamp,providerTimestamp,source,aircraft,hubsSucceeded,hubsTotal}=await fetchLiveAircraft();
    liveMarkers.forEach(m=>m.remove());
    liveMarkers=[];
    if($('#liveTrafficToggle').checked){
      aircraft.forEach(a=>{
        const color=a.onGround?'#6b7680':'#58d6ff';
        const m=L.marker([a.lat,a.lon],{icon:planeIcon(a.headingDeg,color)})
          .bindTooltip(`${a.callsign} · ${fmtAlt(a.altitudeFt)}`)
          .bindPopup(`<b>${a.callsign}</b><br>Altitude: ${fmtAlt(a.altitudeFt)}<br>Speed: ${fmtSpeed(a.speedKt)}<br>Track: ${Number.isFinite(a.headingDeg)?Math.round(a.headingDeg)+'°':'—'}<br>Category: ${a.category} · Squawk: ${a.squawk}<br>${a.onGround?'On ground':'Airborne'}<br><small>ADS-B position ${fmtAge(a.seenSeconds)}</small>`)
          .addTo(liveLayer);
        liveMarkers.push(m);
      });
    }
    statusEl.textContent=`LIVE · ${source}`;
    statusEl.className='pill';
    $('#liveAircraftCount').textContent=aircraft.length.toLocaleString();
    $('#liveTrafficUpdated').textContent=providerTimestamp?providerTimestamp.toLocaleTimeString()+' · '+Math.max(0,Math.round((Date.now()-providerTimestamp.getTime())/1000))+'s old':'fetch '+timestamp.toLocaleTimeString();
    const coverage=$('#liveTrafficCoverage'); if(coverage) coverage.textContent=`${hubsSucceeded}/${hubsTotal} hubs responding`;
    const sourceEl=$('#liveTrafficSource'); if(sourceEl) sourceEl.textContent=source.toUpperCase();
  }catch(err){
    console.warn('Live traffic fetch failed',err);
    statusEl.textContent='LIVE TRAFFIC UNAVAILABLE';
    $('#liveAircraftCount').textContent='—';
    $('#liveTrafficUpdated').textContent='Unavailable — '+(err?.message||'network error');
    const coverage=$('#liveTrafficCoverage'); if(coverage) coverage.textContent='No ADS-B hub responded';
  }finally{
    liveInFlight=false;
  }
}

function startLivePolling(){
  refreshLiveTraffic();
  clearInterval(liveTimer);
  liveTimer=setInterval(refreshLiveTraffic,LIVE_REFRESH_MS);
}

function populateSelect(sel,defaultIndex){
  sel.innerHTML=LOCATIONS.map(a=>`<option value="${a.iata}">${a.iata} — ${a.city}</option>`).join('');
  if(defaultIndex!=null)sel.selectedIndex=defaultIndex;
}

function pathLength(path){let d=0;for(let i=1;i<path.length;i++)d+=haversine(path[i-1],path[i]);return d;}

function addRoute({label,type,fromIata,toIata,altitude}){
  const from=findLoc(fromIata), to=findLoc(toIata);
  if(!from||!to||from.iata===to.iata)return;
  const steps=type==='Drone'?16:48;
  const path=greatCircle(from,to,steps);
  routes.push({
    id:'R'+(routeSeq++),
    label:label||`${type==='Drone'?'Drone':'Flight'} ${from.iata}→${to.iata}`,
    type,from,to,
    altitude:Number(altitude)||(type==='Drone'?120:35000),
    color:nextColor(), path
  });
  render();
}

function removeRoute(id){routes=routes.filter(r=>r.id!==id);render();}

// Approximates the closest approach between two corridors by sampling
// points from each path against the other. Good enough for a prototype
// strategic-deconfliction demo; not a precise segment-intersection solver.
function closestApproach(pathA,pathB){
  let best=null;
  for(const pa of pathA){
    for(const pb of pathB){
      const d=haversine(pa,pb);
      if(!best||d<best.distanceKm)best={distanceKm:d,pointA:pa,pointB:pb};
    }
  }
  return best;
}

function findConflicts(thresholdKm){
  const out=[];
  for(let i=0;i<routes.length;i++){
    for(let j=i+1;j<routes.length;j++){
      const A=routes[i],B=routes[j],ap=closestApproach(A.path,B.path);
      if(!ap||ap.distanceKm>thresholdKm)continue;
      const severity=ap.distanceKm<=thresholdKm*0.35?'SEVERE':ap.distanceKm<=thresholdKm*0.7?'HIGH':'MODERATE';
      out.push({a:A,b:B,distanceKm:ap.distanceKm,mid:{lat:(ap.pointA.lat+ap.pointB.lat)/2,lon:(ap.pointA.lon+ap.pointB.lon)/2},severity});
    }
  }
  return out.sort((x,y)=>x.distanceKm-y.distanceKm);
}

function sevChipClass(s){return s==='SEVERE'?'risk-high-text':s==='HIGH'?'risk-moderate-text':'risk-mild-text';}
function metricClass(hasConflicts){return hasConflicts?'metricbox-severe':'metricbox-low';}

function renderRoutesTable(){
  $('#routeCountPill').textContent=`${routes.length} ROUTE${routes.length===1?'':'S'}`;
  $('#routesBody').innerHTML=routes.map(r=>`<tr>
    <td><i style="display:inline-block;width:22px;height:4px;border-radius:3px;margin-right:8px;vertical-align:middle;background:${r.color}"></i>${r.label}</td>
    <td>${r.type}</td>
    <td>${r.from.iata} → ${r.to.iata}</td>
    <td>${Math.round(pathLength(r.path))} km</td>
    <td><button type="button" class="btn secondary" data-remove="${r.id}" style="padding:6px 10px;font-size:9px">REMOVE</button></td>
  </tr>`).join('') || `<tr><td colspan="5" class="muted" style="padding:14px 10px">No routes yet — add at least two corridors to check for conflicts.</td></tr>`;
  $('#routesBody').querySelectorAll('[data-remove]').forEach(b=>b.addEventListener('click',()=>removeRoute(b.dataset.remove)));
}

function renderMap(){
  map.clear();
  routes.forEach(r=>{
    map.plotRoute(r.path,r.color,'original',5);
    map.addMarker(r.from,`${r.label} · origin`,r.color,`<b>${r.label}</b><br>${r.type} · origin ${r.from.iata}`);
    map.addMarker(r.to,`${r.label} · destination`,r.color,`<b>${r.label}</b><br>${r.type} · destination ${r.to.iata}`);
  });
  if(routes.length)map.fit(routes.map(r=>r.path));
}

function renderConflicts(){
  conflictMarkers.forEach(m=>m.remove());
  conflictMarkers=[];

  const thresholdKm=Math.max(1,Number($('#threshold').value)||120);
  const conflicts=findConflicts(thresholdKm);

  conflicts.forEach(c=>{
    const color=c.severity==='SEVERE'?'#ff493d':c.severity==='HIGH'?'#ff9d00':'#ffd166';
    const m=L.marker([c.mid.lat,c.mid.lon],{icon:L.divIcon({className:'fw-conflict-icon',html:`<div class="conflict-ping" style="--c:${color}">⚠</div>`,iconSize:[30,30],iconAnchor:[15,15]})})
      .bindTooltip(`${c.a.label} × ${c.b.label} · ${c.distanceKm.toFixed(0)} km apart`)
      .addTo(map.map);
    conflictMarkers.push(m);
  });

  const box=$('#conflictSummary').closest('.drone-storm-metric');
  box.classList.remove('metricbox-low','metricbox-severe');
  box.classList.add(metricClass(conflicts.length>0));
  $('#conflictSummary').innerHTML=conflicts.length
    ? `<span class="risk-high-text">⚠ ${conflicts.length} CONFLICT${conflicts.length>1?'S':''} FLAGGED</span><br><small class="muted">Within the ${thresholdKm} km separation threshold.</small>`
    : `<span class="risk-low-text">✓ NO CONFLICTS</span><br><small class="muted">All corridors keep more than ${thresholdKm} km separation.</small>`;

  $('#opsConflictCount').textContent=conflicts.length?`${conflicts.length} FLAGGED`:'CLEAR';

  $('#conflictsBody').innerHTML=conflicts.map(c=>`<tr>
    <td>${c.a.label}</td><td>${c.b.label}</td>
    <td>${c.distanceKm.toFixed(1)} km</td>
    <td><span class="risk-chip ${sevChipClass(c.severity)}">${c.severity}</span></td>
  </tr>`).join('') || `<tr><td colspan="4" class="muted" style="padding:14px 10px">No corridor pairs are within the current threshold.</td></tr>`;
}

function render(){
  renderRoutesTable();
  renderMap();
  renderConflicts();
}

(async()=>{
  map=new MapEngine('trafficMap',{center:[21,79],zoom:5}); await map.init();
  liveLayer=L.layerGroup().addTo(map.map);
  populateSelect($('#fromLoc'),0);
  populateSelect($('#toLoc'),1);

  $('#liveTrafficToggle').addEventListener('change',()=>{
    if($('#liveTrafficToggle').checked){map.map.addLayer(liveLayer);refreshLiveTraffic();}
    else{liveMarkers.forEach(m=>m.remove());liveMarkers=[];map.map.removeLayer(liveLayer);}
  });
  startLivePolling();

  $('#routeForm').addEventListener('submit',e=>{
    e.preventDefault();
    addRoute({
      label:$('#routeLabel').value.trim(),
      type:$('#routeType').value,
      fromIata:$('#fromLoc').value,
      toIata:$('#toLoc').value,
      altitude:$('#routeAltitude').value
    });
    $('#routeLabel').value='';
  });
  $('#routeType').addEventListener('change',()=>{$('#routeAltitude').value=$('#routeType').value==='Drone'?120:35000;});
  $('#threshold').addEventListener('input',renderConflicts);
  $('#clearRoutes').addEventListener('click',()=>{routes=[];render();});

  // Seed a few demo corridors so the map and conflict table show something
  // meaningful immediately, including at least one flagged pair.
  addRoute({label:'Flight AI-201 BOM→DEL',type:'Aviation',fromIata:'BOM',toIata:'DEL',altitude:35000});
  addRoute({label:'Flight 6E-884 AMD→HYD',type:'Aviation',fromIata:'AMD',toIata:'HYD',altitude:34000});
  addRoute({label:'Flight UK-955 PNQ→CCU',type:'Aviation',fromIata:'PNQ',toIata:'CCU',altitude:36000});
  addRoute({label:'Drone FW-11 BKC→Juhu',type:'Drone',fromIata:'BKC',toIata:'JUHU',altitude:120});
})();
