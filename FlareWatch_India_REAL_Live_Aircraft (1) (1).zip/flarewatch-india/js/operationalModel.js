import {pathDistance, greatCircle} from './routeEngine.js';

export const RISK_BANDS = [
  {min:0,max:24,label:'LOW'},
  {min:25,max:49,label:'MODERATE'},
  {min:50,max:74,label:'HIGH'},
  {min:75,max:100,label:'SEVERE'}
];

const clamp=(v,min=0,max=100)=>Math.max(min,Math.min(max,v));
const level=s=>RISK_BANDS.find(b=>s>=b.min&&s<=b.max)?.label||'SEVERE';
const num=v=>Number.isFinite(Number(v))?Number(v):0;
const rank={LOW:0,MODERATE:1,HIGH:2,SEVERE:3};

export function xraySeverity(xray=''){
  const m=String(xray).match(/^([ABCMX])(\d+(?:\.\d+)?)/i);
  if(!m)return 0;
  const c=m[1].toUpperCase(), n=num(m[2]);
  const base={A:2,B:5,C:15,M:40,X:75}[c]||0;
  const mult={A:.5,B:1,C:2,M:3,X:2}[c]||1;
  return clamp(base+n*mult);
}

export function spaceWeatherSeverity(wx={}){
  // NOAA Kp is the primary geomagnetic driver. X-ray, solar-wind speed,
  // and southward Bz provide secondary context; they do not by themselves
  // mean that an operational route is in a storm.
  const kp=clamp(num(wx.kpIndex)*8,0,72);
  const x=xraySeverity(wx.xrayFlux)*0.22;
  const wind=clamp((num(wx.solarWindSpeed)-450)/12,0,10);
  const bz=clamp(Math.max(0,-num(wx.bzGsm))*0.8,0,8);
  return clamp(kp+x+wind+bz);
}

function sensitivity(profile={},kind='Aviation'){
  let s=0;
  const gnss={Low:5,Medium:12,High:20}[profile.gnssDependency]||10;
  const backup={INS:-8,Visual:-4,None:8}[profile.backupNavigation]||0;
  const comm={
    'VHF + SATCOM':-5,'HF / SATCOM':3,'VHF Only':5,'VHF':4,
    'SATCOM':-4,'RF + LTE':-4,'Dual Link':-6,'LTE / 5G':0,
    'Single Link':8,'Other':2
  }[profile.communicationSystem]??2;
  const critical={Routine:0,Important:4,High:7,Critical:12}[profile.missionCriticality]??2;
  s+=gnss+backup+comm+critical;
  if(profile.receiverType==='Single Frequency')s+=5;
  if(profile.augmentation==='None')s+=4;
  if(profile.augmentation==='RTK')s-=2;
  if(profile.augmentation==='PPP')s-=1;
  if(kind==='Aviation'){
    s+=clamp((num(profile.cruiseAltitude)-20000)/5000,0,12);
    s+=clamp((num(profile.flightDuration)-3)*1.2,0,8);
    s+={None:0,Low:2,Medium:5,High:9}[profile.polarExposure]||1;
    if(profile.routeType==='Polar / High-Latitude'||profile.routeType==='High Latitude')s+=7;
  }else{
    s+=clamp(num(profile.altitude)/30,0,8);
    s+=clamp((num(profile.missionDuration)-1)*1.5,0,6);
    s+=clamp(num(profile.operatingRadius)/3,0,6);
    if(profile.returnToHome==='Disabled')s+=7;
  }
  return clamp(s,0,100);
}

function radiationSeverity(wx={},point={},profile={},kind='Aviation'){
  // Prefer NOAA GOES proton flux when available. Kp is not treated as a
  // direct radiation measurement.
  const p=num(wx.protonFlux);
  let s=0;
  if(p>=100000)s=90;
  else if(p>=10000)s=75;
  else if(p>=1000)s=55;
  else if(p>=100)s=35;
  else if(p>=10)s=22;
  const lat=Math.abs(num(point.lat));
  const latitudeFactor=clamp((lat-35)/45,0,1)*15;
  const altitudeFactor=kind==='Aviation'?clamp((num(profile.cruiseAltitude)-25000)/10000,0,1)*12:clamp(num(profile.altitude)/500,0,4);
  return clamp(s+latitudeFactor+altitudeFactor);
}

export function pointRisk(point,wx,profile,kind='Aviation'){
  const lat=Math.abs(num(point.lat));
  // Latitude matters because geomagnetic/ionospheric effects are generally
  // stronger away from the equator. This is a prototype exposure model.
  const geo=clamp((lat/65)**2*24);
  const space=spaceWeatherSeverity(wx);
  const sens=sensitivity(profile,kind);
  const duration=kind==='Aviation'?clamp(num(profile.flightDuration)*0.8,0,8):clamp(num(profile.missionDuration)*1.2,0,6);
  const altitude=kind==='Aviation'?clamp((num(profile.cruiseAltitude)-20000)/4000,0,10):clamp(num(profile.altitude)/40,0,6);
  const exposure=clamp(space*0.78+geo*0.08+sens*0.12+duration*0.06+altitude*0.04);
  const radiation=radiationSeverity(wx,point,profile,kind);
  const gnss=clamp(space*0.72+geo*0.55+(profile.gnssDependency==='High'?12:profile.gnssDependency==='Medium'?7:3));
  const comm=clamp(space*0.55+geo*0.40+(['HF / SATCOM','Single Link','VHF Only'].includes(profile.communicationSystem)?12:4));
  return {
    exposure,risk:level(exposure),
    radiation,radiationRisk: radiation>=75?'EXTREME':radiation>=50?'HIGH':radiation>=25?'MODERATE':'LOW',
    gnss,gnssRisk:level(gnss),
    communication:comm,communicationRisk:level(comm)
  };
}

export function scoreRoute(path,wx,profile,kind='Aviation'){
  const points=path.map(p=>({...p,...pointRisk(p,wx,profile,kind)}));
  const peak=points.reduce((a,b)=>a.exposure>b.exposure?a:b,points[0]||{exposure:0});
  const avg=points.length?points.reduce((s,p)=>s+p.exposure,0)/points.length:0;
  const severe=points.filter(p=>rank[p.risk]>=2).length;
  const overall=clamp(peak.exposure*0.55+avg*0.35+(severe/(points.length||1))*10);
  return {points,peak,average:avg,severeSegments:severe,score:overall,risk:level(overall)};
}

export function routeMetrics(path,profile,kind='Aviation'){
  const distance=pathDistance(path);
  if(kind==='Aviation'){
    const requested=num(profile.flightDuration);
    const speed=profile.__speedKph||distance/(requested||Math.max(1,distance/820));
    const hours=speed>0?distance/speed:(requested||distance/820);
    const fuelRate={'Commercial Jet':7.9,'Business Jet':5.2,'Turboprop':2.4,'Military / Special Mission':8.6,'Other':null}[profile.aircraftType];
    return {distance,hours,speed,fuel:fuelRate==null?null:distance*fuelRate,fuelRate};
  }
  const hours=num(profile.missionDuration)||Math.max(.1,distance/35);
  const energyRate={Multirotor:8.5,'Fixed-Wing':4.2,'Hybrid VTOL':5.8,'Heavy-Lift':12}[profile.droneType]||null;
  return {distance,hours,energy:energyRate==null?null:distance*energyRate};
}

function stormDetour(origin,destination,wx,profile){
  const original=greatCircle(origin,destination,64);
  const severity=spaceWeatherSeverity(wx);
  // The stronger the modeled disturbance, the larger the prototype avoidance
  // corridor. This is deliberately a demonstrator route, not an airway.
  const offset=severity>=75?2.0:severity>=50?1.2:0.65;
  const direction=origin.lat>=0&&destination.lat>=0?-1:1;
  const longitudeShift=offset*0.55;
  const suggested=original.map((p,i)=>{
    if(i===0||i===original.length-1)return {...p};
    const t=i/(original.length-1),bend=Math.sin(Math.PI*t);
    return {lat:p.lat+direction*offset*bend,lon:p.lon+longitudeShift*bend};
  });
  return {original,suggested};
}

export function suggestAviationRoute(origin,destination,wx,profile){
  const original=greatCircle(origin,destination,64);
  const base=scoreRoute(original,wx,profile,'Aviation');
  const detour=stormDetour(origin,destination,wx,profile);
  const alt=scoreRoute(detour.suggested,wx,profile,'Aviation');
  // Severe conditions always trigger a visible avoidance corridor. High risk
  // triggers it when the alternate model score improves.
  const should=base.risk==='SEVERE'||(base.risk==='HIGH'&&alt.score<base.score-1.5);
  const reasons=[];
  if(base.risk==='SEVERE')reasons.push(`Modeled space-weather exposure is SEVERE (${base.score.toFixed(0)}/100); the prototype applies an avoidance corridor.`);
  if(base.risk==='HIGH'&&should)reasons.push('Modeled exposure is HIGH and the alternate corridor reduces the route score.');
  if(Math.max(...original.map(p=>Math.abs(p.lat)))>55)reasons.push('Original route reaches a high-latitude corridor where geomagnetic exposure is higher.');
  if(num(wx.kpIndex)>=5)reasons.push(`NOAA planetary Kp is ${num(wx.kpIndex).toFixed(1)}, indicating elevated geomagnetic activity.`);
  if(profile.gnssDependency==='High')reasons.push('High GNSS dependency increases modeled navigation sensitivity.');
  if(profile.backupNavigation==='None')reasons.push('No backup navigation increases operational sensitivity.');
  if(Number.isFinite(num(wx.protonFlux))&&num(wx.protonFlux)>=10)reasons.push(`NOAA GOES proton flux is ${num(wx.protonFlux).toFixed(1)} pfu or higher, so the radiation indicator is elevated.`);
  if(should)reasons.push('Suggested corridor is intentionally displaced from the original path so the map and fuel/time trade-off are visible.');
  return {original,suggested:should?detour.suggested:original,rerouted:should,originalScore:base,suggestedScore:should?alt:base,reasons};
}

export function suggestDronePath(path,wx,profile){
  const base=scoreRoute(path,wx,profile,'Drone');
  if(rank[base.risk]<2)return {original:path,suggested:path,rerouted:false,originalScore:base,suggestedScore:base,reasons:[]};
  const shift=spaceWeatherSeverity(wx)>=75?0.025:0.015;
  const candidate=path.map((p,i)=>i===0||i===path.length-1?p:{lat:p.lat-shift,lon:p.lon+shift});
  const alt=scoreRoute(candidate,wx,profile,'Drone');
  const should=base.risk==='SEVERE'||(base.risk==='HIGH'&&alt.score<base.score);
  const reasons=[];
  if(base.risk==='SEVERE')reasons.push('Severe modeled space-weather exposure triggers a visible avoidance path.');
  if(base.risk==='HIGH'&&should)reasons.push('Suggested path lowers the modeled exposure score.');
  if(profile.gnssDependency==='High')reasons.push('High GNSS dependency increases navigation sensitivity.');
  if(profile.backupNavigation==='None')reasons.push('No backup navigation is configured.');
  return {original:path,suggested:should?candidate:path,rerouted:should,originalScore:base,suggestedScore:should?alt:base,reasons};
}

export function compare(original,suggested,profile,kind){
  const a=routeMetrics(original,profile,kind),b=routeMetrics(suggested,profile,kind);
  const originalRisk=profile.__originalScore?.score??0;
  const suggestedRisk=profile.__suggestedScore?.score??originalRisk;
  const reduction=originalRisk>0?clamp((originalRisk-suggestedRisk)/originalRisk*100):0;
  return {original:a,suggested:b,distanceDelta:b.distance-a.distance,durationDelta:b.hours-a.hours,riskReduction:reduction};
}
