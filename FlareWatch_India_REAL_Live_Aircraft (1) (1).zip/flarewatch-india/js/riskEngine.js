export const CONFIG={
  kp:{elevated:4,high:6,storm:7},
  xray:{B:1,C:2,M:4,X:6},
  operation:{Aviation:2,Drone:2,Satellite:3,'Navigation & Positioning':2,'Radio Communication':2,Other:1}
};

const n=v=>Number.isFinite(Number(v))?Number(v):0;
const add=(arr,score,text)=>{arr.score+=score;if(text)arr.reasons.push(text)};

export function riskEngine(wx,input={}){
  const box={score:0,reasons:[]};
  const kp=n(wx.kpIndex);
  if(kp>=7)add(box,5,'Kp ≥ 7: strong geomagnetic activity');
  else if(kp>=6)add(box,4,'Kp 6+: moderate-to-strong geomagnetic activity');
  else if(kp>=4)add(box,2,'Kp 4+: unsettled geomagnetic activity');

  const xf=String(wx.xrayFlux||'');
  const cls=xf[0];
  if(CONFIG.xray[cls]){
    add(box,CONFIG.xray[cls],`${cls}-class X-ray activity`);
  }

  const op=input.operation||'Other';
  add(box,CONFIG.operation[op]||1,null);
  if(['Aviation','Drone','Navigation & Positioning'].includes(op)){
    add(box,0,`${op} has navigation/communication dependencies`);
  }

  if(op==='Aviation') aviationFactors(box,input);
  if(op==='Drone') droneFactors(box,input);
  if(op==='Navigation & Positioning') navigationFactors(box,input);
  if(input.sensitivity==='Conservative') add(box,1,'Conservative assessment mode');

  const level=box.score>=12?'STORM':box.score>=8?'HIGH':box.score>=4?'ELEVATED':'LOW';
  return {score:box.score,level,reasons:box.reasons,impact:impacts(level,op),recommendation:recommend(level)};
}

function aviationFactors(b,i){
  const alt=n(i.cruiseAltitude);
  const dur=n(i.flightDuration);
  if(alt>=35000)add(b,2,'Cruise altitude ≥ 35,000 ft');
  else if(alt>=25000)add(b,1,'Cruise altitude ≥ 25,000 ft');
  if(dur>=8)add(b,2,'Long-duration flight (≥ 8 h)');
  else if(dur>=4)add(b,1,'Extended flight duration');
  if(i.polarExposure==='High')add(b,3,'Polar exposure: high');
  else if(i.polarExposure==='Medium')add(b,1,'Polar exposure: medium');
  if(i.routeType==='Polar / High-Latitude')add(b,2,'High-latitude route');
  if(i.communicationSystem==='HF / SATCOM')add(b,1,'HF / SATCOM communications');
  if(i.navigationSystem==='Single-GNSS')add(b,2,'Single-GNSS navigation');
  if(i.navigationSystem==='Multi-GNSS')add(b,0,null);
  if(i.missionCriticality==='Critical')add(b,2,'Mission criticality: critical');
  else if(i.missionCriticality==='High')add(b,1,'Mission criticality: high');
}
function droneFactors(b,i){
  const alt=n(i.altitude), radius=n(i.operatingRadius), dur=n(i.missionDuration);
  if(alt>=120)add(b,1,'Higher-altitude drone operation');
  if(radius>=10)add(b,2,'Large operating radius (≥ 10 km)');
  else if(radius>=5)add(b,1,'Expanded operating radius');
  if(dur>=4)add(b,1,'Long mission duration');
  if(i.gnssDependency==='High')add(b,3,'GNSS dependency: high');
  else if(i.gnssDependency==='Medium')add(b,1,'GNSS dependency: medium');
  if(i.backupNavigation==='None')add(b,2,'No backup navigation');
  if(i.returnToHome==='Disabled')add(b,2,'Return-to-home disabled');
  if(i.communicationSystem==='Single Link')add(b,1,'Single communication link');
  if(i.missionCriticality==='Critical')add(b,2,'Mission criticality: critical');
  else if(i.missionCriticality==='High')add(b,1,'Mission criticality: high');
}
function navigationFactors(b,i){
  if(i.gnssDependency==='High')add(b,3,'GNSS dependency: high');
  else if(i.gnssDependency==='Medium')add(b,1,'GNSS dependency: medium');
  if(i.receiverType==='Single Frequency')add(b,1,'Single-frequency receiver');
  if(i.augmentation==='None')add(b,1,'No augmentation selected');
  if(i.backupNavigation==='None')add(b,2,'No backup navigation');
  if(i.navigationSystem==='NavIC')add(b,0,null);
  if(i.missionCriticality==='Critical')add(b,2,'Mission criticality: critical');
}

function impacts(level,op){
  if(level==='STORM')return['Significant space-weather disturbance possible','GNSS, HF radio and satellite communication impacts may occur','Use official operational advisories and contingency procedures'];
  if(level==='HIGH')return['Elevated navigation and communication concerns','Monitor GNSS/HF performance closely','Review current official space-weather guidance'];
  if(level==='ELEVATED')return['Minor-to-moderate navigation or communication disturbance is possible','Continue monitoring conditions during the operation'];
  return['No elevated operational concern indicated by this prototype score','Continue routine monitoring'];
}
function recommend(level){
  if(level==='STORM')return'Follow applicable official operational guidance and maintain contingency procedures.';
  if(level==='HIGH')return'Increase monitoring and review current official space-weather advisories.';
  if(level==='ELEVATED')return'Continue monitoring live space-weather conditions before and during the operation.';
  return'Routine monitoring is appropriate for this prototype assessment.';
}
